// Network node: HTTP API, consensus participation, gossip to peers and catch-up sync.
import fs from 'node:fs';
import http from 'node:http';
import path from 'node:path';
import { Chain } from './chain.js';
import { Consensus, memorySignLog } from './consensus.js';
import { addressFromPublicKey, generateKeyPair, isAddress, keyTypeOf, parseMultisig, publicKeyFromPrivate, PQ_KEY_TYPES } from './crypto.js';
import { createHello, acceptHello, completeHello, StealthRefusal, SESSION_MAX_AGE_MS } from './p2p.js';
import { createTransfer, createTx, txHash } from './tx.js';
import { formatAmount, parseAmount } from './coin.js';
import { RUNG_IDS, LEVEL_NAMES, alertLevel, rungInfo } from './tripwire.js';
import { assetView } from './rwa.js';
import { Firewall } from './firewall.js';
import { totalLocked, vestingEnd } from './state.js';

// Post-quantum (ML-DSA-65) signatures are ~3.3 KB each, so blocks and proposals can be a few MB.
const MAX_BODY_BYTES = 16_000_000;
const EXPLORER_HTML = new URL('../public/explorer.html', import.meta.url);
const SYNC_INTERVAL_MS = 3_000;
const DISCOVERY_INTERVAL_MS = 60_000;
const MAX_DISCOVERED = 32; // peers this node adds by itself (seeds + peer exchange)
const NEW_PEERS_PER_ROUND = 8;
const PRUNE_INTERVAL_MS = 60_000;
const SNAPSHOTS_KEPT = 2;
const MAX_PEERS = 64;
const MAX_INBOUND_SESSIONS = 1024;

export class Node {
  // Public-network options (all off by default, so a local devnet behaves as before):
  //   trustProxy: take the client IP from X-Forwarded-For when the request comes from a local reverse proxy
  //   faucetAddressCooldownMs / faucetIpCooldownMs: how often one address / one IP may use the faucet
  //   txsPerMinutePerIp: cap on POST /txs per client IP (0 = unlimited)
  //   firewall: options for the node firewall (firewall.js), e.g. { rates: { tx: 60 }, allow: ['203.0.113.7'] };
  //   on by default; loopback is exempt unless firewall.exemptLocal is false
  //   stealth: hide the peer channel from everyone except known nodes (configured peers, active
  //   validators, and stealthAllow identity keys). Strangers get "not found" before any cryptography,
  //   so a validator can't be found by scanning or worn down by handshake floods.
  // Autonomous discovery: seeds = public node addresses (e.g. https://rpc.cyvber.com) to learn the
  //   network from; every minute the node asks its seeds and peers for the nodes they know (GET /peers),
  //   shakes hands with new ones (which proves they run this chain) and joins them. discoverPrivate
  //   allows loopback/LAN addresses (tests and private networks only).
  // Fast sync: snapshotEvery = keep a snapshot of the state every N blocks for new nodes to start
  // from; trustedBlock = { height, hash } makes an empty node start from that snapshot (taken from
  // a peer, checked against the hash) instead of replaying every block since genesis.
  constructor({ genesis, dataDir = null, port = 0, host = '127.0.0.1', peers = [], validatorKey = null, faucetKey = null, faucetAmount = '100',
    trustProxy = false, faucetAddressCooldownMs = 60_000, faucetIpCooldownMs = 0, txsPerMinutePerIp = 0, snapshotEvery = 1000, trustedBlock = null,
    publicUrl = null, encryptPeers = true, firewall = {}, stealth = false, stealthAllow = [], seeds = [], discoverPrivate = false, log = console.log }) {
    this.genesis = genesis;
    this.dataDir = dataDir;
    this.chain = new Chain(genesis, { dataDir });
    this.snapshotEvery = snapshotEvery;
    this.trustedBlock = trustedBlock;
    this.snapshots = new Map(); // height -> snapshot (in memory; also written to dataDir/snapshots)
    // Peer discovery: a node with a publicUrl announces it to its peers on start, so a new validator
    // joins the gossip without anyone editing other nodes' configs.
    this.relayed = new Set(); // consensus messages already passed on
    this.announced = new Set(); // peers that joined by announcing themselves (not in our config)
    this.peerFailures = new Map(); // peer URL -> failed calls in a row
    // Encrypted peer links (p2p.js): ML-KEM-768 key exchange, ML-DSA identities, AES-256-GCM.
    // A validator's identity is its validator key; any other node uses a fresh ML-DSA-65 key.
    this.encryptPeers = encryptPeers;
    const ownPq = validatorKey && PQ_KEY_TYPES.includes(keyTypeOf(publicKeyFromPrivate(validatorKey)));
    this.identityKey = ownPq ? validatorKey : generateKeyPair('ml-dsa-65').privateKey;
    this.identityPublic = publicKeyFromPrivate(this.identityKey);
    this.outbound = new Map(); // peer URL -> Promise<Session>
    this.pinnedPeers = new Map(); // peer URL -> identity key seen at the first handshake
    this.inbound = new Map(); // session id -> Session
    this.helloNonces = new Set();
    this.publicUrl = publicUrl ? publicUrl.replace(/\/$/, '') : null;
    this.port = port;
    this.host = host;
    this.peers = peers.map((p) => p.replace(/\/$/, ''));
    this.configuredPeers = new Set(this.peers);
    this.seeds = seeds.map((p) => p.replace(/\/$/, ''));
    this.discoverPrivate = discoverPrivate;
    this.discovering = false;
    this.lastDiscovery = null;
    this.stealth = stealth;
    this.stealthAllow = new Set(stealthAllow);
    this.trustedIdentities = new Set(); // identities of configured peers, learned at our handshakes with them
    this.firewall = new Firewall(firewall, {
      log: (m) => this.log(m),
      trustedPeer: (key) => this.trustedIdentities.has(key) || this.chain.validators.has(key),
    });
    this.validatorKey = validatorKey;
    this.faucetKey = faucetKey;
    this.faucetUnits = parseAmount(faucetAmount, genesis.coin.decimals);
    this.trustProxy = trustProxy;
    this.faucetAddressLimit = new RateLimiter(1, faucetAddressCooldownMs);
    this.faucetIpLimit = new RateLimiter(1, faucetIpCooldownMs);
    this.txLimit = new RateLimiter(txsPerMinutePerIp, 60_000);
    this.log = log;
    this.timers = [];
    this.syncing = false;
  }

  async start() {
    this.server = http.createServer((req, res) => this.#handle(req, res));
    // Firewall layer 1: drop blocked addresses before reading anything, cap connections per address,
    // and time out slow senders (slowloris) instead of holding sockets forever.
    this.server.on('connection', (socket) => {
      const ip = socket.remoteAddress ?? '';
      if (!this.firewall.connectionOpened(ip)) return socket.destroy();
      socket.once('close', () => this.firewall.connectionClosed(ip));
    });
    this.server.headersTimeout = 10_000;
    this.server.requestTimeout = 60_000;
    this.server.keepAliveTimeout = 5_000;
    this.server.maxHeadersCount = 64;
    await new Promise((resolve, reject) => {
      this.server.once('error', (err) => reject(err.code === 'EADDRINUSE' ? new Error(`port ${this.port} is already in use (is another node running?)`) : err));
      this.server.listen(this.port, this.host, resolve);
    });
    this.port = this.server.address().port;
    this.url = `http://${this.host}:${this.port}`;
    if (this.trustedBlock && this.chain.height < this.trustedBlock.height) await this.#fastSync();
    this.#loadSnapshots();
    this.chain.onCommit((block) => this.#maybeSnapshot(block.header.height));
    await this.discover();
    await this.sync();
    await this.#announce();
    this.timers.push(setInterval(() => this.discover(), DISCOVERY_INTERVAL_MS));
    this.timers.push(setInterval(() => this.sync(), SYNC_INTERVAL_MS));
    this.timers.push(setInterval(() => this.#announce(), 60_000));
    this.timers.push(setInterval(() => this.#pruneSessions(), 60_000));
    this.timers.push(setInterval(() => [this.faucetAddressLimit, this.faucetIpLimit, this.txLimit, this.firewall].forEach((l) => l.prune()), PRUNE_INTERVAL_MS));
    if (this.validatorKey) {
      this.consensus = new Consensus({
        chain: this.chain,
        privateKey: this.validatorKey,
        broadcast: (msg) => this.#broadcast('/consensus', msg),
        // A finalized block already travels in the consensus 'commit' message; no second copy.
        onEquivocation: (a, b) => this.#reportDoubleSign(a, b),
        signLog: this.dataDir ? fileSignLog(path.join(this.dataDir, 'sign-state.json')) : memorySignLog(),
        log: this.log,
      });
      this.consensus.start();
    }
    const role = this.validatorKey ? `validator ${addressFromPublicKey(publicKeyFromPrivate(this.validatorKey))}` : 'full node';
    this.log(`cyvber node listening on ${this.url} (${role}), chain ${this.chain.genesis.chainId}, height ${this.chain.height}`);
    return this;
  }

  async stop() {
    this.consensus?.stop();
    this.timers.forEach(clearInterval);
    this.timers = [];
    // Close open keep-alive connections right away: peers keep sending messages, so waiting for
    // them to go idle could take a long time.
    const closed = new Promise((resolve) => this.server.close(resolve));
    this.server.closeAllConnections?.();
    await closed;
  }

  // Starts an empty node from a peer's snapshot of the trusted block.
  async #fastSync() {
    const { height, hash } = this.trustedBlock;
    for (const peer of this.peers) {
      const snap = await this.#peerCall(peer, 'GET', `/snapshot?height=${height}`, null, 120_000).catch(() => null);
      if (!snap) continue;
      try {
        Chain.verifySnapshot(this.genesis, snap, { height, hash });
        this.chain = new Chain(this.genesis, { dataDir: this.dataDir, snapshot: snap });
        this.log(`started from snapshot at block ${height} (${hash.slice(0, 12)}) from ${peer}`);
        return;
      } catch (err) {
        this.log(`snapshot from ${peer} rejected: ${err.message}`);
      }
    }
    throw new Error(`no peer served a valid snapshot of block ${height}; ask a peer which snapshot heights it has (GET /snapshot)`);
  }

  #snapshotDir() {
    return this.dataDir ? path.join(this.dataDir, 'snapshots') : null;
  }

  #loadSnapshots() {
    const dir = this.#snapshotDir();
    if (!dir || !fs.existsSync(dir)) return;
    for (const file of fs.readdirSync(dir).filter((f) => f.endsWith('.json')).sort().slice(-SNAPSHOTS_KEPT)) {
      try {
        const snap = JSON.parse(fs.readFileSync(path.join(dir, file), 'utf8'));
        this.snapshots.set(snap.height, snap);
      } catch {
        // ignore a damaged snapshot; a new one is made later
      }
    }
  }

  #maybeSnapshot(height) {
    if (!this.snapshotEvery || height % this.snapshotEvery !== 0) return;
    const snap = this.chain.snapshot();
    this.snapshots.set(height, snap);
    const dir = this.#snapshotDir();
    if (dir) {
      fs.mkdirSync(dir, { recursive: true });
      fs.writeFileSync(path.join(dir, `${String(height).padStart(10, '0')}.json`), JSON.stringify(snap));
    }
    for (const h of [...this.snapshots.keys()].sort((a, b) => a - b).slice(0, -SNAPSHOTS_KEPT)) {
      this.snapshots.delete(h);
      if (dir) fs.rmSync(path.join(dir, `${String(h).padStart(10, '0')}.json`), { force: true });
    }
  }

  // Submits proof that a validator signed two different blocks; it is slashed and removed.
  #reportDoubleSign(a, b) {
    const strip = ({ type, height, round, blockHash, validRound, validator, signature }) => ({ type, height, round, blockHash, ...(type === 'proposal' ? { validRound } : {}), validator, signature });
    const reporter = publicKeyFromPrivate(this.validatorKey);
    try {
      const tx = createTx({ type: 'evidence', chainId: this.genesis.chainId, voteA: strip(a), voteB: strip(b), fee: BigInt(this.genesis.minFee), nonce: this.chain.pendingNonce(addressFromPublicKey(reporter)) }, { privateKey: this.validatorKey });
      const result = this.chain.addTx(tx);
      this.log(`validator ${addressFromPublicKey(a.validator)} signed two different blocks at height ${a.height}: ${result.ok ? 'evidence submitted' : `evidence not submitted (${result.error})`}`);
      if (result.ok && !result.known) this.#broadcast('/txs', tx);
    } catch (err) {
      this.log(`could not submit double-sign evidence: ${err.message}`);
    }
  }

  #acceptCommit(msg) {
    const height = msg.block?.header?.height;
    if (!Number.isSafeInteger(height) || height <= this.chain.height) return { ok: true };
    if (height > this.chain.height + 1) return { ok: true, ahead: true };
    const result = this.chain.addBlock(msg.block);
    return result.ok ? { ok: true } : { ok: false, error: result.error };
  }

  // Tells peers how to reach this node; they add it to their gossip list.
  async #announce() {
    if (!this.publicUrl) return;
    await Promise.all(this.peers.map((peer) => this.#peerCall(peer, 'POST', '/peers', { url: this.publicUrl, genesisHash: this.chain.genesisHash }).catch(() => null)));
  }

  // Pulls missing blocks from any peer that is ahead of us.
  async sync() {
    if (this.syncing || !this.peers.length) return;
    this.syncing = true;
    try {
      for (const peer of this.peers) {
        const status = await this.#peerCall(peer, 'GET', '/status').catch(() => null);
        if (!status || status.chainId !== this.chain.genesis.chainId || status.genesisHash !== this.chain.genesisHash) continue;
        while (status.height > this.chain.height) {
          const block = await this.#peerCall(peer, 'GET', `/blocks/${this.chain.height + 1}`).catch(() => null);
          if (!block) break;
          const result = this.chain.addBlock(block);
          if (!result.ok) {
            this.log(`sync from ${peer} stopped at height ${this.chain.height + 1}: ${result.error}`);
            break;
          }
        }
      }
    } finally {
      this.syncing = false;
    }
  }

  #broadcast(route, body) {
    for (const peer of this.peers) this.#peerCall(peer, 'POST', route, body).catch(() => this.#peerFailed(peer));
  }

  // Passes on a message received from a peer, only where it is needed: the configured validators
  // reach each other directly, so messages between them go on only to peers that joined by
  // announcing themselves, and messages from those go on to everyone else.
  #relay(route, body, fromKey) {
    const fromAnnounced = [...this.announced].some((url) => this.pinnedPeers.get(url) === fromKey);
    const targets = fromAnnounced ? this.peers.filter((url) => this.pinnedPeers.get(url) !== fromKey) : [...this.announced];
    for (const peer of targets) this.#peerCall(peer, 'POST', route, body).catch(() => this.#peerFailed(peer));
  }

  // ---- autonomous peer discovery ----

  // A peer address that may be shared and dialled: plain http(s), and public unless discoverPrivate.
  #shareablePeer(value) {
    let url;
    try { url = new URL(value); } catch { return null; }
    if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password || url.search || url.hash) return null;
    if (!this.discoverPrivate && isPrivateHost(url.hostname)) return null;
    return url.origin + url.pathname.replace(/\/$/, '');
  }

  // Public addresses of the nodes this one knows (answer to GET /peers).
  publicPeers() {
    const list = [this.publicUrl, ...this.peers].filter(Boolean).map((p) => this.#shareablePeer(p)).filter(Boolean);
    return [...new Set(list)].slice(0, MAX_PEERS);
  }

  // Asks the seeds and current peers which nodes they know, then joins new ones. A new node, or a new
  // validator, needs only one seed address; everything else is found by itself. Each new address is
  // checked with a handshake (same chain id and genesis, identity pinned) before it is used, and one
  // identity keeps one address.
  async discover() {
    if (this.discovering) return this.lastDiscovery;
    this.discovering = true;
    let added = 0;
    const found = new Set();
    try {
      const sources = [...new Set([...this.seeds, ...this.peers])].slice(0, 24);
      // Known peers are asked over the encrypted channel (a wiretap must not learn the network map);
      // a seed we are not yet linked to is a public address, asked over plain HTTP(S).
      const ask = (src) => (this.encryptPeers && this.peers.includes(src) ? this.#peerCall(src, 'GET', '/peers') : fetchJson(`${src}/peers`, { timeoutMs: 5_000 }));
      const lists = await Promise.all(sources.map((src) => ask(src).catch(() => null)));
      for (const seed of this.seeds) found.add(seed);
      for (const list of lists) for (const p of (Array.isArray(list?.peers) ? list.peers.slice(0, MAX_PEERS) : [])) found.add(p);
      for (const candidate of found) {
        if (added >= NEW_PEERS_PER_ROUND || this.announced.size >= MAX_DISCOVERED || this.peers.length >= MAX_PEERS) break;
        const peer = this.#shareablePeer(candidate) ?? (this.seeds.includes(candidate) ? candidate : null);
        if (!peer || peer === this.publicUrl || peer === this.url || this.peers.includes(peer)) continue;
        if (await this.#joinDiscovered(peer)) added++;
      }
    } finally {
      this.discovering = false;
    }
    this.lastDiscovery = { at: Date.now(), candidates: found.size, added, peers: this.peers.length };
    return this.lastDiscovery;
  }

  async #joinDiscovered(peer) {
    let peerKey = null;
    try {
      if (this.encryptPeers) {
        peerKey = (await this.#session(peer)).peerKey; // refused unless it runs this exact chain
        if (peerKey === this.identityPublic) throw new Error('that is this node');
      } else {
        const status = await fetchJson(`${peer}/status`, { timeoutMs: 5_000 });
        if (status.chainId !== this.genesis.chainId || status.genesisHash !== this.chain.genesisHash) throw new Error('different chain');
      }
    } catch {
      this.outbound.delete(peer);
      this.pinnedPeers.delete(peer);
      return false;
    }
    if (peerKey) for (const old of [...this.announced]) if (old !== peer && this.pinnedPeers.get(old) === peerKey) this.#dropPeer(old);
    if (this.peers.includes(peer) || this.peers.length >= MAX_PEERS) return false;
    this.peers.push(peer);
    this.announced.add(peer);
    this.log(`discovered peer ${peer}`);
    if (this.publicUrl) this.#peerCall(peer, 'POST', '/peers', { url: this.publicUrl, genesisHash: this.chain.genesisHash }).catch(() => null);
    return true;
  }

  // ---- encrypted peer channel (see p2p.js) ----

  // One request to a peer over the encrypted channel; returns the decrypted response body.
  async #peerCall(peer, method, path, body = null, timeoutMs = 5_000, retried = false) {
    if (!this.encryptPeers) {
      return fetchJson(`${peer}${path}`, method === 'GET' ? { timeoutMs } : { method, timeoutMs, headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) });
    }
    const session = await this.#session(peer);
    const request = session.encryptRequest({ method, path, body });
    const res = await fetch(`${peer}/p2p`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(request), signal: AbortSignal.timeout(timeoutMs) });
    const out = await res.json().catch(() => ({}));
    if (res.status === 409 && !retried) { // the peer restarted or dropped the session: shake hands again
      this.outbound.delete(peer);
      return this.#peerCall(peer, method, path, body, timeoutMs, true);
    }
    if (!res.ok) throw new Error(out.error ?? `HTTP ${res.status}`);
    const reply = session.decryptReply(request.seq, out.ct);
    this.peerFailures.delete(peer);
    if (reply.status >= 400) throw new Error(reply.body?.error ?? `HTTP ${reply.status}`);
    return reply.body;
  }

  #session(peer) {
    const current = this.outbound.get(peer);
    if (current && !current.expiredAt?.()) return current;
    const opening = (async () => {
      const { hello, kemPrivateKey } = createHello({ chainId: this.genesis.chainId, genesisHash: this.chain.genesisHash, identityKey: this.identityKey, identityPublicKey: this.identityPublic });
      const reply = await fetchJson(`${peer}/p2p/handshake`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ hello }) });
      const session = completeHello(hello, kemPrivateKey, reply, { expectedPeerKey: this.pinnedPeers.get(peer) ?? null });
      if (!this.pinnedPeers.has(peer)) this.pinnedPeers.set(peer, session.peerKey);
      if (this.configuredPeers.has(peer)) this.trustedIdentities.add(session.peerKey); // the operator's own peers are never banned
      return session;
    })();
    opening.expiredAt = () => false;
    opening.then((session) => { opening.expiredAt = () => session.expired; }, () => this.outbound.delete(peer));
    this.outbound.set(peer, opening);
    return opening;
  }

  // Adds an announced peer after checking it answers with the announcer's own identity. Each identity
  // keeps one address (a newer announcement replaces the older one).
  async #verifiedPeer(peer, peerKey) {
    const known = this.peers.includes(peer);
    if (!known) {
      this.outbound.delete(peer);
      this.pinnedPeers.delete(peer);
    }
    let session;
    try {
      session = await this.#session(peer);
    } catch {
      if (!known) { this.outbound.delete(peer); this.pinnedPeers.delete(peer); }
      return { status: 400, body: { error: 'could not reach that address' } };
    }
    if (session.peerKey !== peerKey) {
      if (!known) { this.outbound.delete(peer); this.pinnedPeers.delete(peer); }
      return { status: 400, body: { error: 'that address belongs to a different node' } };
    }
    if (known) return { status: 200, body: { ok: true, known: true } };
    for (const old of [...this.announced]) if (this.pinnedPeers.get(old) === peerKey) this.#dropPeer(old);
    if (this.peers.length >= MAX_PEERS) return { status: 503, body: { error: 'peer list full' } };
    this.peers.push(peer);
    this.announced.add(peer);
    this.log(`new peer ${peer}`);
    return { status: 200, body: { ok: true } };
  }

  #dropPeer(peer) {
    this.peers = this.peers.filter((p) => p !== peer);
    this.announced.delete(peer);
    this.outbound.delete(peer);
    this.pinnedPeers.delete(peer);
    this.peerFailures.delete(peer);
  }

  // Announced peers that stay unreachable are dropped (configured peers are kept).
  #peerFailed(peer) {
    const n = (this.peerFailures.get(peer) ?? 0) + 1;
    this.peerFailures.set(peer, n);
    if (n >= 20 && this.announced.has(peer)) {
      this.log(`dropping unreachable peer ${peer}`);
      this.#dropPeer(peer);
    }
  }

  #pruneSessions() {
    for (const [sid, s] of this.inbound) if (Date.now() - s.lastUsed > 2 * SESSION_MAX_AGE_MS) this.inbound.delete(sid);
    if (this.helloNonces.size > 50_000) this.helloNonces.clear(); // hellos older than a minute are refused anyway
  }

  // POST /p2p/handshake and POST /p2p: answer a peer over the encrypted channel.
  async #p2p(parts, body, res, ip) {
    const known = (key) => this.trustedIdentities.has(key) || this.chain.validators.has(key) || this.stealthAllow.has(key);
    const ctx = { chainId: this.genesis.chainId, genesisHash: this.chain.genesisHash, identityKey: this.identityKey, identityPublicKey: this.identityPublic, seenNonces: this.helloNonces, admit: this.stealth ? known : null };
    if (parts[1] === 'handshake' && parts.length === 2) {
      let accepted;
      try {
        accepted = acceptHello(body?.hello, ctx);
      } catch (err) {
        if (err instanceof StealthRefusal) {
          this.firewall.penalize(ip, 'not-found');
          return send(res, 404, { error: 'not found' }); // stealth: looks like no peer channel here
        }
        this.firewall.penalize(ip, 'bad-handshake');
        return send(res, 400, { error: `handshake refused: ${err.message}` });
      }
      const banned = this.firewall.peerBannedFor(accepted.session.peerKey);
      if (banned) return send(res, 403, { error: `this node identity is blocked for ${Math.ceil(banned / 1000)} s after invalid messages` });
      if (this.inbound.size >= MAX_INBOUND_SESSIONS) {
        const oldest = [...this.inbound.values()].sort((a, b) => a.lastUsed - b.lastUsed)[0];
        this.inbound.delete(oldest.sid);
      }
      this.inbound.set(accepted.session.sid, accepted.session);
      return send(res, 200, accepted.reply);
    }
    if (parts.length !== 1) return send(res, 404, { error: 'not found' });
    const session = this.inbound.get(body?.sid);
    if (!session) {
      this.firewall.penalize(ip, this.stealth ? 'not-found' : 'unknown-session');
      return this.stealth ? send(res, 404, { error: 'not found' }) : send(res, 409, { error: 'unknown session; shake hands again' });
    }
    if (this.firewall.peerBannedFor(session.peerKey)) {
      this.inbound.delete(session.sid);
      return send(res, 403, { error: 'this node identity is blocked after invalid messages' });
    }
    let request;
    try {
      request = session.decryptRequest(body);
    } catch (err) {
      // Failed authentication means the message was forged or altered; a replay is cheaper to forgive.
      const reason = /replayed/.test(err.message) ? 'unknown-session' : 'tampered';
      this.firewall.penalize(ip, reason);
      this.firewall.penalizePeer(session.peerKey, reason);
      return send(res, 400, { error: err.message });
    }
    const url = new URL(String(request?.path ?? ''), 'http://local');
    const inner = parts2(url.pathname);
    const out = collector();
    try {
      if (request.method === 'GET' && inner.length === 1 && inner[0] === 'network') send(out, 200, await this.#network());
      else if (request.method === 'GET' && inner.length) this.#get(inner, out, url.searchParams);
      else if (request.method === 'POST') await this.#post(inner, request.body, out, null, { fromPeer: true, peerKey: session.peerKey });
      else send(out, 404, { error: 'not found' });
    } catch (err) {
      send(out, err.status ?? 500, { error: err.status ? err.message : 'internal error' });
    }
    const { status, body: replyBody } = await out.done;
    return send(res, 200, session.encryptReply(body.seq, { status, body: replyBody }));
  }

  async #handle(req, res) {
    res.setHeader('access-control-allow-origin', '*');
    res.setHeader('access-control-allow-headers', 'content-type');
    res.setHeader('x-content-type-options', 'nosniff');
    res.setHeader('referrer-policy', 'no-referrer');
    if (req.method === 'OPTIONS') return send(res, 204, null);
    let url;
    try {
      url = new URL(req.url, 'http://local');
    } catch {
      return send(res, 400, { error: 'bad request' });
    }
    const parts = url.pathname.split('/').filter(Boolean);
    const ip = this.#clientIp(req);
    // Firewall layers 2-4: rate per kind of request, body size per route, points for misbehaviour.
    const kind = req.method !== 'POST' ? 'read'
      : parts[0] === 'p2p' ? (parts[1] === 'handshake' ? 'handshake' : 'p2p')
        : parts[0] === 'txs' ? 'tx' : parts[0] === 'faucet' ? 'faucet' : 'other';
    const blocked = this.firewall.checkRequest(ip, kind);
    if (blocked) {
      res.setHeader('retry-after', String(Math.max(1, Math.ceil(blocked.retryAfterMs / 1000))));
      return send(res, blocked.status, { error: blocked.error });
    }
    res.once('finish', () => {
      if (res.statusCode === 404) this.firewall.penalize(ip, 'not-found');
    });
    try {
      if (req.method === 'GET' && parts.length === 1 && parts[0] === 'network') return send(res, 200, await this.#network());
      if (req.method === 'GET' && parts.length === 1 && parts[0] === 'firewall') {
        // Blocked addresses are shown only to the node's own operator (a direct local connection).
        const local = ['127.0.0.1', '::1', '::ffff:127.0.0.1'].includes(req.socket.remoteAddress) && !req.headers['x-forwarded-for'];
        return send(res, 200, this.firewall.status({ detail: local }));
      }
      if (req.method === 'GET') return this.#get(parts, res, url.searchParams);
      const limit = this.firewall.bodyLimit(kind);
      if (req.method === 'POST' && parts[0] === 'p2p') return await this.#p2p(parts, await readJson(req, limit), res, ip);
      if (req.method === 'POST') return this.#post(parts, await readJson(req, limit), res, ip);
      this.firewall.penalize(ip, 'bad-method');
      return send(res, 405, { error: 'method not allowed' });
    } catch (err) {
      if (err.status === 400) this.firewall.penalize(ip, 'bad-json');
      if (err.status === 413) this.firewall.penalize(ip, 'too-large');
      return send(res, err.status ?? 500, { error: err.status ? err.message : 'internal error' });
    }
  }

  #latest(query, summarize) {
    const limit = clampLimit(query.get('limit'), 10);
    const out = [];
    for (let h = this.chain.height; h > this.chain.base && out.length < limit; h--) out.push(summarize(h));
    return out;
  }

  #blockSummary(block) {
    return {
      height: block.header.height,
      hash: block.hash,
      timestamp: block.header.timestamp,
      proposer: addressFromPublicKey(block.header.proposer),
      txCount: block.txs.length,
      fees: block.txs.reduce((sum, tx) => sum + BigInt(tx.fee), 0n).toString(),
      signatures: block.commit.precommits.map((p) => addressFromPublicKey(p.validator)),
      round: block.commit.round,
    };
  }

  #txSummary(hash) {
    const found = this.chain.getTx(hash);
    if (!found) return null;
    const { tx, block } = found;
    return { status: 'confirmed', hash, height: block.header.height, timestamp: block.header.timestamp, ...txFields(tx) };
  }

  #get(parts, res, query) {
    const { chain } = this;
    const { decimals } = chain.genesis.coin;
    if (parts.length === 0) {
      res.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-cache' }); // always the current explorer
      return res.end(fs.readFileSync(EXPLORER_HTML));
    }
    if (parts[0] === 'status' && parts.length === 1) {
      return send(res, 200, {
        chainId: chain.genesis.chainId,
        genesisHash: chain.genesisHash,
        coin: chain.genesis.coin,
        height: chain.height,
        tipHash: chain.tipHash,
        validators: chain.validatorList.map(addressFromPublicKey),
        historyFrom: chain.base + 1,
        p2p: { encrypted: this.encryptPeers, keyExchange: 'ML-KEM-768 (FIPS 203) + X25519 hybrid', stealth: this.stealth, identity: addressFromPublicKey(this.identityPublic), cipher: 'AES-256-GCM', inboundSessions: this.inbound.size },
        snapshots: [...this.snapshots.values()].map((sn) => ({ height: sn.height, hash: sn.block.hash })),
        self: this.validatorKey ? addressFromPublicKey(publicKeyFromPrivate(this.validatorKey)) : null,
        quorum: chain.quorum,
        supply: `${formatAmount(chain.state.supply, decimals)} ${chain.genesis.coin.symbol}`,
        maxSupply: `${formatAmount(chain.genesis.maxSupply, decimals)} ${chain.genesis.coin.symbol}`,
        mempool: chain.mempool.size,
        txCount: chain.txIndex.size,
        consensus: this.consensus?.status() ?? null,
        peers: this.peers,
        faucet: Boolean(this.faucetKey),
      });
    }
    if (parts[0] === 'genesis' && parts.length === 1) return send(res, 200, chain.genesis);
    if (parts[0] === 'peers' && parts.length === 1) return send(res, 200, { peers: this.publicPeers(), seeds: this.seeds.length, discovery: this.lastDiscovery });
    if (parts[0] === 'tripwire' && parts.length === 1) {
      const canary = chain.state.canary;
      if (!canary) return send(res, 404, { error: 'this chain has no Q-Day Tripwire' });
      const symbol = chain.genesis.coin.symbol;
      const level = alertLevel(canary.broken);
      return send(res, 200, {
        level, levelName: LEVEL_NAMES[level],
        ed25519RetiredAt: chain.retiredAt('ed25519') ?? null,
        revealDelayBlocks: chain.tripwire.revealDelayBlocks, graceBlocks: chain.tripwire.graceBlocks,
        bountyPoolLeft: `${formatAmount(canary.pool, decimals)} ${symbol}`,
        pendingClaims: Object.keys(canary.commits).length,
        rungs: RUNG_IDS.filter((id) => Object.hasOwn(chain.tripwire.bounties, id)).map((id) => ({
          ...rungInfo(id),
          bounty: `${formatAmount(chain.tripwire.bounties[id], decimals)} ${symbol}`,
          broken: canary.broken[id] ?? null,
        })),
      });
    }
    // ARS-1 real-world assets: the list, one asset with its holders, and an account's holdings.
    if (parts[0] === 'assets' && parts.length <= 2) {
      const rwa = chain.state.rwa;
      if (parts.length === 2) {
        const view = assetView(rwa, parts[1]);
        return view ? send(res, 200, view) : send(res, 404, { error: 'unknown asset' });
      }
      const assets = Object.values(rwa?.assets ?? {}).map(({ assetId, symbol, name, class: cls, supply, maxSupply, holders, paused, roles, rules, legal }) => ({
        assetId, symbol, name, class: cls, supply, maxSupply, holders, paused, issuer: roles.issuer, adminKeys: rules.adminKeys, offering: legal.offering,
      }));
      return send(res, 200, { count: assets.length, assets });
    }
    if (parts[0] === 'accounts' && parts.length === 3 && parts[2] === 'assets') {
      if (!isAddress(parts[1])) return send(res, 400, { error: 'invalid address' });
      const rwa = chain.state.rwa;
      const holdings = Object.entries(rwa?.balances ?? {})
        .filter(([, bals]) => bals[parts[1]])
        .map(([assetId, bals]) => ({ assetId, symbol: rwa.assets[assetId].symbol, balance: bals[parts[1]].balance, frozen: Boolean(bals[parts[1]].frozen) }));
      const kyc = Object.entries(rwa?.kyc ?? {}).filter(([, reg]) => reg[parts[1]]).map(([compliance, reg]) => ({ compliance, ...reg[parts[1]] }));
      return send(res, 200, { address: parts[1], holdings, kyc });
    }
    if (parts[0] === 'snapshot' && parts.length === 1) {
      if (!query.has('height')) return send(res, 200, { heights: [...this.snapshots.keys()], every: this.snapshotEvery });
      const snap = this.snapshots.get(Number(query.get('height')));
      return snap ? send(res, 200, snap) : send(res, 404, { error: `no snapshot at that height; available: ${[...this.snapshots.keys()].join(', ') || 'none yet'}` });
    }
    if (parts[0] === 'validators' && parts.length === 1) {
      const symbol = chain.genesis.coin.symbol;
      return send(res, 200, {
        active: chain.validatorList.length,
        quorum: chain.quorum,
        minStake: `${formatAmount(chain.params.minStake, decimals)} ${symbol}`,
        validators: chain.state.validators.map((v) => ({
          address: addressFromPublicKey(v.key),
          publicKey: v.key,
          keyType: keyTypeOf(v.key),
          owner: v.owner,
          operator: v.operator ?? null,
          stake: v.stake.toString(),
          stakeFormatted: `${formatAmount(v.stake, decimals)} ${symbol}`,
          status: v.status,
          genesis: Boolean(v.genesis),
          missedInARow: v.missed,
          jailedUntil: v.jailedUntil ?? null,
          unbondAt: v.unbondAt ?? null,
        })),
        banned: [...chain.state.banned].map(addressFromPublicKey),
        rewards: chain.genesis.rewards ? {
          poolLeft: chain.state.rewardPool.toString(), paid: chain.state.rewardsPaid.toString(),
          poolLeftFormatted: `${formatAmount(chain.state.rewardPool, decimals)} ${symbol}`, paidFormatted: `${formatAmount(chain.state.rewardsPaid, decimals)} ${symbol}`,
          perYear: chain.genesis.rewards.years.map((y) => `${formatAmount(y, decimals)} ${symbol}`),
        } : null,
      });
    }
    if (parts[0] === 'blocks' && parts.length === 1) {
      return send(res, 200, this.#latest(query, (h) => this.#blockSummary(chain.getBlock(h))));
    }
    if (parts[0] === 'blocks' && parts.length === 2) {
      const height = parts[1] === 'latest' ? chain.height : Number(parts[1]);
      const block = chain.getBlock(height);
      if (!block) return send(res, 404, { error: 'block not found' });
      return send(res, 200, { ...block, txHashes: block.txs.map(txHash), proposerAddress: addressFromPublicKey(block.header.proposer) });
    }
    if (parts[0] === 'accounts' && (parts.length === 2 || (parts.length === 3 && parts[2] === 'txs'))) {
      if (!isAddress(parts[1])) return send(res, 400, { error: 'invalid address' });
      if (parts.length === 3) {
        const hashes = chain.addressIndex.get(parts[1]) ?? [];
        const limit = clampLimit(query.get('limit'), 25);
        return send(res, 200, { total: hashes.length, txs: hashes.slice(-limit).reverse().map((h) => this.#txSummary(h)) });
      }
      const account = chain.state.get(parts[1]);
      return send(res, 200, {
        address: parts[1],
        balance: account.balance.toString(),
        balanceFormatted: `${formatAmount(account.balance, decimals)} ${chain.genesis.coin.symbol}`,
        nonce: account.nonce,
        pendingNonce: chain.pendingNonce(parts[1]),
        migratedTo: account.migratedTo ?? null,
        pqCommit: account.pqCommit ?? null,
        txCount: chain.addressIndex.get(parts[1])?.length ?? 0,
        validator: chain.validatorList.some((v) => addressFromPublicKey(v) === parts[1]),
        locked: totalLocked(account, Date.now()).toString(),
        lockedFormatted: `${formatAmount(totalLocked(account, Date.now()), decimals)} ${chain.genesis.coin.symbol}`,
        vesting: (account.vesting ?? []).map((g) => ({ ...g, fullyUnlockedAt: vestingEnd(g) })),
        ownsValidators: chain.state.validators.filter((v) => v.owner === parts[1]).map((v) => addressFromPublicKey(v.key)),
      });
    }
    if (parts[0] === 'txs' && parts.length === 1) {
      const limit = clampLimit(query.get('limit'), 10);
      const out = [];
      for (let h = chain.height; h > chain.base && out.length < limit; h--) {
        for (const tx of [...chain.getBlock(h).txs].reverse()) {
          if (out.length < limit) out.push(this.#txSummary(txHash(tx)));
        }
      }
      return send(res, 200, out);
    }
    if (parts[0] === 'txs' && parts.length === 2) {
      if (chain.mempool.has(parts[1])) {
        const tx = chain.mempool.get(parts[1]);
        return send(res, 200, { status: 'pending', hash: parts[1], ...txFields(tx) });
      }
      const summary = this.#txSummary(parts[1]);
      return summary ? send(res, 200, summary) : send(res, 404, { error: 'transaction not found' });
    }
    return send(res, 404, { error: 'not found' });
  }

  // Every validator's view of the chain, gathered by this node from its peers, so a browser that can
  // only reach this node (e.g. through rpc.cyvber.com) can still see which validators are online.
  async #network() {
    if (this.networkCache && Date.now() - this.networkCache.at < 2000) return this.networkCache.value;
    const summarize = (s) => s && { validator: s.self, height: s.height, consensus: s.consensus };
    const own = { validator: this.validatorKey ? addressFromPublicKey(publicKeyFromPrivate(this.validatorKey)) : null, height: this.chain.height, consensus: this.consensus?.status() ?? null };
    const peers = await Promise.all(this.peers.map((p) => this.#peerCall(p, 'GET', '/status').then(summarize).catch(() => null)));
    const value = { validators: this.chain.validatorList.map(addressFromPublicKey), nodes: [own, ...peers.filter(Boolean)] };
    this.networkCache = { at: Date.now(), value };
    return value;
  }

  // The caller's IP. Behind a reverse proxy on this machine, the real client is the LAST entry of
  // X-Forwarded-For: that one is added by our proxy. Earlier entries come from the client and can be
  // forged (e.g. "127.0.0.1" to pass as local and slip past the firewall).
  #clientIp(req) {
    const remote = req.socket.remoteAddress ?? '';
    const local = remote === '127.0.0.1' || remote === '::1' || remote === '::ffff:127.0.0.1';
    if (this.trustProxy && local) {
      const forwarded = String(req.headers['x-forwarded-for'] ?? '').split(',').map((x) => x.trim()).filter(Boolean).at(-1);
      if (forwarded) return forwarded;
    }
    return remote;
  }

  #post(parts, body, res, ip, { fromPeer = false, peerKey = null } = {}) {
    const { chain } = this;
    // Gossip between nodes only over the encrypted channel; wallets still send transactions directly.
    if (this.encryptPeers && !fromPeer && ['blocks', 'consensus', 'peers'].includes(parts[0])) {
      return send(res, 403, { error: 'node-to-node messages must use the encrypted peer channel (POST /p2p)' });
    }
    if (parts[0] === 'txs' && parts.length === 1) {
      const wait = fromPeer ? 0 : this.txLimit.check(ip);
      if (wait) return send(res, 429, { error: `too many transactions from your address, try again in ${formatWait(wait)}` });
      const result = chain.addTx(body);
      if (!result.ok) {
        // Wallets with a stale nonce or low balance make honest mistakes, so those cost little; a forged
        // signature costs more. Transactions relayed by peers are not scored (they may just be late).
        if (!fromPeer) this.firewall.penalize(ip, /signature/.test(result.error) ? 'bad-signature' : 'invalid-tx');
        return send(res, 400, { error: result.error });
      }
      if (!result.known) this.#broadcast('/txs', body);
      return send(res, 202, { hash: result.hash });
    }
    if (parts[0] === 'blocks' && parts.length === 1) {
      const height = body?.header?.height;
      if (Number.isSafeInteger(height) && height <= chain.height) return send(res, 200, { ok: true, known: true });
      if (Number.isSafeInteger(height) && height > chain.height + 1) {
        this.sync();
        return send(res, 202, { ok: true, syncing: true });
      }
      const result = chain.addBlock(body);
      if (!result.ok) {
        if (fromPeer) this.firewall.penalizePeer(peerKey, 'invalid-block');
        return send(res, 400, { error: result.error });
      }
      this.log(`accepted finalized block ${height} (${body.txs.length} txs) from peer`);
      this.#relay('/blocks', body, peerKey);
      return send(res, 200, { ok: true });
    }
    if (parts[0] === 'consensus' && parts.length === 1) {
      // Valid messages seen for the first time are passed on to our peers, so validators that are
      // not directly connected (e.g. an outside validator that only knows rpc.cyvber.com) still hear
      // each other.
      const id = typeof body?.signature === 'string' ? `${body.type}:${body.signature.slice(0, 128)}` : body?.type === 'commit' ? `commit:${body.block?.hash}` : null;
      if (id && this.relayed.has(id)) return send(res, 200, { ok: true, known: true });
      const result = this.consensus ? this.consensus.handle(body) : (body?.type === 'commit' ? this.#acceptCommit(body) : { ok: true });
      if (result.ahead) this.sync();
      if (!result.ok) {
        if (fromPeer) this.firewall.penalizePeer(peerKey, 'invalid-consensus');
        return send(res, 400, { error: result.error });
      }
      if (id) {
        this.relayed.add(id);
        if (this.relayed.size > 20_000) this.relayed.delete(this.relayed.values().next().value);
        this.#relay('/consensus', body, peerKey);
      }
      return send(res, 200, { ok: true });
    }
    if (parts[0] === 'faucet' && parts.length === 1) return this.#faucet(body, res, ip);
    if (parts[0] === 'peers' && parts.length === 1) {
      let url;
      try {
        url = new URL(body?.url);
      } catch {
        return send(res, 400, { error: 'url must be an http(s) URL' });
      }
      if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password || url.search || url.hash) return send(res, 400, { error: 'url must be a plain http(s) URL' });
      if (body.genesisHash !== chain.genesisHash) return send(res, 400, { error: 'different chain' });
      const peer = url.origin + url.pathname.replace(/\/$/, '');
      if (peer === this.publicUrl || peer === this.url || (this.peers.includes(peer) && !this.encryptPeers)) return send(res, 200, { ok: true, known: true });
      if (!this.encryptPeers || !peerKey) {
        if (this.peers.includes(peer)) return send(res, 200, { ok: true, known: true });
        if (this.peers.length >= MAX_PEERS) return send(res, 503, { error: 'peer list full' });
        this.peers.push(peer);
        this.announced.add(peer);
        return send(res, 200, { ok: true });
      }
      // Prove the address belongs to the node announcing it: shake hands with it and compare identities.
      return this.#verifiedPeer(peer, peerKey).then((verdict) => send(res, verdict.status, verdict.body));
    }
    return send(res, 404, { error: 'not found' });
  }

  #faucet(body, res, ip) {
    if (!this.faucetKey) return send(res, 404, { error: 'this node has no faucet' });
    const address = body?.address;
    if (!isAddress(address)) return send(res, 400, { error: 'invalid address' });
    const addressWait = this.faucetAddressLimit.peek(address);
    if (addressWait) return send(res, 429, { error: `this address already received test CYV, try again in ${formatWait(addressWait)}` });
    const ipWait = this.faucetIpLimit.peek(ip);
    if (ipWait) return send(res, 429, { error: `the faucet was already used from your network, try again in ${formatWait(ipWait)}` });
    const { chain } = this;
    const faucetAddress = addressFromPublicKey(publicKeyFromPrivate(this.faucetKey));
    const tx = createTransfer({
      chainId: chain.genesis.chainId,
      privateKey: this.faucetKey,
      to: address,
      amount: this.faucetUnits,
      fee: BigInt(chain.genesis.minFee),
      nonce: chain.pendingNonce(faucetAddress),
      memo: 'testnet faucet',
    });
    const result = chain.addTx(tx);
    if (!result.ok) return send(res, 503, { error: `faucet unavailable: ${result.error}` });
    this.faucetAddressLimit.check(address);
    this.faucetIpLimit.check(ip);
    this.#broadcast('/txs', tx);
    return send(res, 202, { hash: result.hash, amount: formatAmount(this.faucetUnits, chain.genesis.coin.decimals) });
  }
}

// Fixed-window limiter: at most `max` events per key per `windowMs`. max 0 or windowMs 0 = unlimited.
export class RateLimiter {
  constructor(max, windowMs, now = () => Date.now()) {
    this.max = max;
    this.windowMs = windowMs;
    this.now = now;
    this.windows = new Map(); // key -> { count, resetAt }
  }

  // Milliseconds until `key` may act again, or 0 if it may act now. Does not record anything.
  peek(key) {
    if (!this.max || !this.windowMs) return 0;
    const w = this.windows.get(key);
    if (!w || w.resetAt <= this.now()) return 0;
    return w.count >= this.max ? w.resetAt - this.now() : 0;
  }

  // Records one event for `key`. Returns 0 if allowed, else milliseconds to wait (and records nothing).
  check(key) {
    const wait = this.peek(key);
    if (wait || !this.max || !this.windowMs) return wait;
    const now = this.now();
    const w = this.windows.get(key);
    if (!w || w.resetAt <= now) this.windows.set(key, { count: 1, resetAt: now + this.windowMs });
    else w.count++;
    return 0;
  }

  prune() {
    const now = this.now();
    for (const [key, w] of this.windows) if (w.resetAt <= now) this.windows.delete(key);
  }
}

function formatWait(ms) {
  const s = Math.ceil(ms / 1000);
  if (s < 60) return `${s} second${s === 1 ? '' : 's'}`;
  const m = Math.ceil(s / 60);
  if (m < 60) return `${m} minute${m === 1 ? '' : 's'}`;
  const h = Math.ceil(m / 60);
  return `${h} hour${h === 1 ? '' : 's'}`;
}

const KEY_NAMES = { 'ml-dsa-87': 'ML-DSA-87', 'ml-dsa-65': 'ML-DSA-65', 'slh-dsa-256s': 'SLH-DSA-256s', 'slh-dsa-128s': 'SLH-DSA-128s', ed25519: 'Ed25519', multisig: 'multisig' };

function txFields(tx) {
  const keyType = keyTypeOf(tx.from);
  const base = { type: tx.type, keyType, from: addressFromPublicKey(tx.from), to: null, amount: '0', fee: tx.fee, nonce: tx.nonce, memo: '' };
  const ms = parseMultisig(tx.from);
  if (ms) base.multisig = `${ms.threshold} of ${ms.keys.length}`;
  switch (tx.type) {
    case 'migrate':
      return { ...base, toKeyType: keyTypeOf(tx.to), to: addressFromPublicKey(tx.to), memo: `Migration to a post-quantum (${KEY_NAMES[keyTypeOf(tx.to)]}) key` };
    case 'pq-commit':
      return { ...base, memo: 'Migration commitment to a post-quantum key', commitment: tx.commitment };
    case 'vest':
      return { ...base, to: tx.to, amount: tx.amount, memo: tx.memo || `Vesting grant: ${tx.lockMonths}-month lock, then ${tx.vestMonths} monthly unlocks`, lockMonths: tx.lockMonths, vestMonths: tx.vestMonths };
    case 'validator-join':
      return { ...base, to: addressFromPublicKey(tx.validator), amount: tx.amount, memo: 'Validator joins with stake' };
    case 'validator-bond':
      return { ...base, to: addressFromPublicKey(tx.validator), amount: tx.amount, memo: 'Adds stake to a validator' };
    case 'validator-leave':
      return { ...base, to: addressFromPublicKey(tx.validator), memo: 'Validator leaves; stake returns after unbonding' };
    case 'validator-unjail':
      return { ...base, to: addressFromPublicKey(tx.validator), memo: 'Validator returns from jail' };
    case 'evidence':
      return { ...base, to: addressFromPublicKey(tx.voteA.validator), memo: `Double-signing evidence at block ${tx.voteA.height}: validator slashed` };
    case 'canary-commit':
      return { ...base, memo: 'Q-Day Tripwire: claim commitment', commitment: tx.commitment };
    case 'canary-reveal':
      return { ...base, memo: `Q-Day Tripwire: ${tx.rung} broken`, rung: tx.rung };
    default:
      return { ...base, to: tx.to, amount: tx.amount, memo: tx.memo ?? '' };
  }
}

const parts2 = (pathname) => pathname.split('/').filter(Boolean);

// What this validator last signed, kept on disk so a restart never produces a conflicting signature.
// Written atomically (temporary file, then rename) before the message is sent.
function fileSignLog(file) {
  let cached;
  return {
    read() {
      if (cached === undefined) {
        try { cached = JSON.parse(fs.readFileSync(file, 'utf8')); } catch { cached = null; }
      }
      return cached;
    },
    write(record) {
      fs.writeFileSync(`${file}.tmp`, JSON.stringify(record));
      fs.renameSync(`${file}.tmp`, file);
      cached = record;
    },
  };
}

// A stand-in for an HTTP response, so the same handlers can answer requests from the encrypted channel.
function collector() {
  let resolve;
  const out = {
    status: 200,
    done: new Promise((r) => { resolve = r; }),
    setHeader() {},
    writeHead(status) { out.status = status; },
    end(data) { resolve({ status: out.status, body: data === undefined ? null : JSON.parse(data) }); },
  };
  return out;
}

function clampLimit(value, fallback) {
  const n = Number(value ?? fallback);
  return Number.isSafeInteger(n) ? Math.min(Math.max(n, 1), 100) : fallback;
}

function send(res, status, body) {
  res.writeHead(status, body === null ? {} : { 'content-type': 'application/json' });
  res.end(body === null ? undefined : JSON.stringify(body));
}

function readJson(req, limit = MAX_BODY_BYTES) {
  return new Promise((resolve, reject) => {
    if (Number(req.headers['content-length']) > limit) { // refuse before reading anything
      reject(Object.assign(new Error('request body too large'), { status: 413 }));
      req.resume();
      return;
    }
    let size = 0;
    const chunks = [];
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > limit) {
        reject(Object.assign(new Error('request body too large'), { status: 413 }));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => {
      try {
        resolve(JSON.parse(Buffer.concat(chunks).toString('utf8') || 'null'));
      } catch {
        reject(Object.assign(new Error('body must be JSON'), { status: 400 }));
      }
    });
    req.on('error', reject);
  });
}

// Loopback, private-LAN, link-local and similar addresses are never shared or dialled by discovery.
export function isPrivateHost(hostname) {
  const h = hostname.replace(/^\[|\]$/g, '').toLowerCase();
  if (h === 'localhost' || h.endsWith('.localhost') || h.endsWith('.local') || h.endsWith('.internal')) return true;
  const v4 = h.match(/^(\d+)\.(\d+)\.(\d+)\.(\d+)$/);
  if (v4) {
    const [a, b] = [Number(v4[1]), Number(v4[2])];
    return a === 0 || a === 10 || a === 127 || (a === 100 && b >= 64 && b <= 127) || (a === 169 && b === 254)
      || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || a >= 224;
  }
  if (h.includes(':')) return h === '::' || h === '::1' || /^f[cd]/.test(h) || /^fe[89ab]/.test(h) || h.startsWith('::ffff:');
  return false;
}

export async function fetchJson(url, { timeoutMs = 15_000, ...options } = {}) {
  const res = await fetch(url, { ...options, signal: AbortSignal.timeout(timeoutMs) });
  const body = await res.json();
  if (!res.ok) throw new Error(body.error ?? `HTTP ${res.status}`);
  return body;
}
