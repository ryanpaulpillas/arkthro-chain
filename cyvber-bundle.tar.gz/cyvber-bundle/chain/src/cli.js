#!/usr/bin/env node
// cyvber command-line tool: keys, running a node, balances, transfers, faucet.
import fs from 'node:fs';
import path from 'node:path';
import { parseArgs } from 'node:util';
import { fileURLToPath } from 'node:url';
import { generateKeyPair, addressFromPublicKey, publicKeyFromPrivate, keyTypeOf, sign, multisigKey, parseMultisig, signMultisigPart, combineMultisig, KEY_TYPES, PQ_KEY_TYPES, DEFAULT_KEY_TYPE } from './crypto.js';
import { createTransfer, createMigration, createMigrationCommit, createTx, migrationRevealCommitment, signingBytes, validatorConsentBytes } from './tx.js';
import { formatAmount, parseAmount } from './coin.js';
import { writeKeyFile, readKeyFile, loadSigningKey, choosePassphrase, encryptKeyFile, decryptKeyFile, isEncrypted, askPassphrase } from './keyfile.js';
import { Node, fetchJson } from './node.js';
import { canaryCommitment, normalizeSolution, RUNG_IDS } from './tripwire.js';
import { RWA_TYPES, assetIdFor } from './rwa.js';

const DEFAULT_RPC = 'http://127.0.0.1:26601';

const USAGE = `cyvber <command> [options]

  keygen --out <file> [--type ml-dsa-87|ml-dsa-65|slh-dsa-256s|slh-dsa-128s|ed25519] [--encrypt]
                                              create a new key file (default: post-quantum ML-DSA-87,
                                              NIST category 5; slh-dsa-256s is hash-based, category 5,
                                              for savings, cold storage and treasuries). --encrypt
                                              protects it with a passphrase (use it for vaults)
  encrypt --key <file> --out <file>           write a passphrase-protected copy of a key file
  check-key --key <file>                      confirm a (backup) key file opens and matches its address
  address --key <file>                        print the address of a key file
  node --config <file>                        run a node
  status [--rpc <url>]                        show chain status
  balance <address> [--rpc <url>]             show an account balance
  send --key <file> --to <address> --amount <CYV> [--fee <CYV>] [--memo <text>] [--rpc <url>]
  faucet <address> [--rpc <url>]              request testnet CYVBER
  migrate-commit --key <old key file> --new-key <post-quantum file> --payer <funded key file> [--rpc <url>]
                                              after a key type is retired, a never-used account sends this
                                              first (paid by --payer, so the old key stays hidden), then
                                              runs migrate once the reveal delay has passed
  pq-commit --key <current key file> --new-key <post-quantum file> [--rpc <url>]
                                              lock in the key this account will migrate to
                                              (do this before its key type is retired)
  migrate --key <current key file> --new-key <post-quantum file> [--rpc <url>]
                                              move a whole account to a different post-quantum key
                                              (Ed25519 -> post-quantum, or rotate e.g. ML-DSA -> SLH-DSA)

Vesting (locked allocations, e.g. team grants)
  vest --key <file> --to <address> --amount <CYV> --lock <months> --vest <months> [--at-start <CYV>]
                                              send CYVBER that unlocks over time: nothing for --lock
                                              months, then equal monthly parts over --vest months

Multi-signature vaults (e.g. 2 of 3 founders must sign)
  multisig create --threshold <m> --keys <a.json,b.json,c.json> --out <vault.json>
                                              make a vault from members' key files (only their public
                                              keys are read); prints the vault's address
  multisig propose --vault <vault.json> --to <address> --amount <CYV> --out <tx.json>
                   [--lock <months> --vest <months>]   prepare an unsigned transfer (or vesting grant)
  multisig sign --tx <tx.json> --key <member key file>  add one member's signature (offline is fine)
  multisig submit --tx <tx.json>              send it once enough members have signed

Staking (validators)
  validators [--rpc <url>]                    list validators, stake and status
  stake join --key <owner key> --validator-key <file> --amount <CYV>
                                              bond CYVBER and add a validator (its key signs too)
  stake add --key <owner key> --validator <address> --amount <CYV>
  stake request --validator-key <file> --operator <address> --amount <CYV> --out <request.json>
                                              (operator) ask for delegated stake: signed by the validator
                                              key, safe to send to the stake provider
  stake delegate --key <stake provider key> --request <request.json>
                                              (provider) lend the stake: the operator runs the validator
                                              and earns its rewards; the stake returns when it leaves
  export-pubkey --key <file> --out <file>     write only the public part of a key file (safe to share)
  stake leave --key <owner key> --validator <address>
                                              leave the set; the stake returns after unbonding
  stake unjail --key <owner key> --validator <address>
                                              return after a downtime jail has ended

Q-Day Tripwire (bounties for proof that classical cryptography is broken)
  canary ladder [--rpc <url>]                 show the bait keys, bounties and the chain's alert level
  canary commit --key <file> --rung <id> --solution <hex>
                                              step 1 of a claim: publish only a hash of the solution
  canary reveal --key <file> --rung <id> --solution <hex>
                                              step 2, after the reveal delay: the chain checks the
                                              solution, pays the bounty and raises its alert level
                                              (rungs: ${RUNG_IDS.join(', ')}; rsa-2048 solution is "<p hex>.<q hex>")

Node firewall
  firewall [--rpc <url>]                      show the firewall's rules, counters and (on your own node)
                                              the addresses and peer identities it is blocking

Real-world assets (ARS-1; every administrator key must be post-quantum)
  asset list [--rpc <url>]                    list tokenized assets
  asset show <assetId> [--rpc <url>]          one asset: roles, rules, documents, holders
  asset holdings <address> [--rpc <url>]      an account's asset units and KYC entries
  asset send --key <file> --tx <fields.json>  sign and send any ARS-1 transaction from a JSON file of
                                              its fields, e.g. {"type":"asset-issue","assetId":"…",
                                              "to":"cy…","amount":"100","docRef":"<sha256 of the document>"}
                                              (types: ${RWA_TYPES.join(', ')})

Default --rpc is ${DEFAULT_RPC}.`;

// Key-file helpers live in keyfile.js; re-exported for scripts that import them from here.
export { writeKeyFile, readKeyFile };

// Node keys are read unattended, so they must be plain files (protected by file permissions).
function plainKey(file) {
  const keys = readKeyFile(file);
  if (isEncrypted(keys)) throw new Error(`${file} is encrypted; a running node needs an unencrypted key file`);
  return keys.privateKey;
}

const postTx = (rpc, tx) => fetchJson(`${rpc}/txs`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(tx) });
const months = (v, name) => {
  const n = Number(v);
  if (!Number.isInteger(n) || n < 0) throw new Error(`--${name} must be a whole number of months`);
  return n;
};

// Signs and sends a transaction of any type from a (possibly passphrase-protected) key file.
async function signAndSend(rpc, keyFile, { extraSigners, attach = {}, ...fields }) {
  const genesis = await fetchJson(`${rpc}/genesis`);
  const key = await loadSigningKey(keyFile);
  if (!key.privateKey) throw new Error(`${keyFile} is a multisig vault; use "cyvber multisig propose"`);
  const account = await fetchJson(`${rpc}/accounts/${addressFromPublicKey(key.publicKey)}`);
  // `attach`: signatures made by others (e.g. an operator's validator consent), added after signing.
  const tx = { ...createTx({ chainId: genesis.chainId, fee: BigInt(genesis.minFee), nonce: account.pendingNonce, ...fields }, { privateKey: key.privateKey, extraSigners }), ...attach };
  const { hash } = await postTx(rpc, tx);
  return { tx, hash, genesis };
}

async function validatorKeyByAddress(rpc, address) {
  const { validators } = await fetchJson(`${rpc}/validators`);
  const v = validators.find((x) => x.address === address);
  if (!v) throw new Error(`${address} is not a registered validator`);
  return v.publicKey;
}

async function main(argv) {
  const [command, ...rest] = argv;
  const { values, positionals } = parseArgs({
    args: rest,
    allowPositionals: true,
    options: {
      out: { type: 'string' },
      type: { type: 'string', default: DEFAULT_KEY_TYPE },
      'new-key': { type: 'string' },
      key: { type: 'string' },
      config: { type: 'string' },
      rpc: { type: 'string', default: DEFAULT_RPC },
      to: { type: 'string' },
      amount: { type: 'string' },
      fee: { type: 'string' },
      memo: { type: 'string' },
      encrypt: { type: 'boolean', default: false },
      lock: { type: 'string' },
      vest: { type: 'string' },
      'at-start': { type: 'string' },
      threshold: { type: 'string' },
      keys: { type: 'string' },
      vault: { type: 'string' },
      tx: { type: 'string' },
      validator: { type: 'string' },
      'validator-key': { type: 'string' },
      'validator-pubkey': { type: 'string' },
      operator: { type: 'string' },
      request: { type: 'string' },
      payer: { type: 'string' },
      rung: { type: 'string' },
      solution: { type: 'string' },
    },
  });
  const rpc = values.rpc.replace(/\/$/, '');

  switch (command) {
    case 'keygen': {
      if (!values.out) throw new Error('--out is required');
      if (!KEY_TYPES.includes(values.type)) throw new Error(`--type must be one of: ${KEY_TYPES.join(', ')}`);
      if (fs.existsSync(values.out)) throw new Error(`${values.out} already exists; refusing to overwrite a key`);
      const passphrase = values.encrypt ? await choosePassphrase() : null;
      const keys = generateKeyPair(values.type);
      const plain = { address: addressFromPublicKey(keys.publicKey), ...keys };
      writeKeyFile(values.out, passphrase ? encryptKeyFile(plain, passphrase) : plain);
      console.log(`wrote ${values.out} (${values.type}${PQ_KEY_TYPES.includes(values.type) ? ', post-quantum' : ''}${passphrase ? ', encrypted' : ''})\naddress ${plain.address}`);
      console.log(passphrase
        ? 'Without the passphrase this file cannot be opened, and nobody can recover it. Store backups and the passphrase separately.'
        : 'Keep this file private: anyone with it controls the funds.');
      return;
    }
    case 'encrypt': {
      if (!values.key || !values.out) throw new Error('--key and --out are required');
      const file = readKeyFile(values.key);
      if (isEncrypted(file)) throw new Error(`${values.key} is already encrypted`);
      if (fs.existsSync(values.out)) throw new Error(`${values.out} already exists; refusing to overwrite a key`);
      writeKeyFile(values.out, encryptKeyFile(file, await choosePassphrase()));
      console.log(`wrote encrypted ${values.out} for ${file.address}\nCheck it with: cyvber check-key --key ${values.out}\nThen delete the unencrypted ${values.key} securely.`);
      return;
    }
    case 'check-key': {
      if (!values.key) throw new Error('--key is required');
      const file = readKeyFile(values.key);
      const keys = isEncrypted(file) ? decryptKeyFile(file, await askPassphrase(`Passphrase for ${path.basename(values.key)}: `)) : file;
      if (publicKeyFromPrivate(keys.privateKey) !== keys.publicKey || addressFromPublicKey(keys.publicKey) !== keys.address) throw new Error('key file does not match its address');
      console.log(`OK: ${values.key} opens and controls ${keys.address} (${keys.type}${isEncrypted(file) ? ', encrypted' : ', NOT encrypted'})`);
      return;
    }
    case 'address': {
      if (!values.key) throw new Error('--key is required');
      console.log(addressFromPublicKey(readKeyFile(values.key).publicKey));
      return;
    }
    case 'node': {
      if (!values.config) throw new Error('--config is required');
      const configPath = path.resolve(values.config);
      const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
      const resolve = (p) => (p ? path.resolve(path.dirname(configPath), p) : null);
      const node = new Node({
        genesis: JSON.parse(fs.readFileSync(resolve(config.genesis), 'utf8')),
        dataDir: resolve(config.dataDir),
        port: config.port,
        host: config.host,
        peers: config.peers ?? [],
        validatorKey: config.validatorKey ? plainKey(resolve(config.validatorKey)) : null,
        faucetKey: config.faucetKey ? plainKey(resolve(config.faucetKey)) : null,
        faucetAmount: config.faucetAmount,
        trustProxy: config.trustProxy,
        faucetAddressCooldownMs: config.faucetAddressCooldownMs,
        faucetIpCooldownMs: config.faucetIpCooldownMs,
        txsPerMinutePerIp: config.txsPerMinutePerIp,
        snapshotEvery: config.snapshotEvery,
        trustedBlock: config.trustedBlock ?? null,
        publicUrl: config.publicUrl ?? null,
        firewall: config.firewall ?? {},
        stealth: Boolean(config.stealth),
        stealthAllow: config.stealthAllow ?? [],
        seeds: config.seeds ?? [],
        discoverPrivate: config.discoverPrivate ?? false,
      });
      // Node.js 24's built-in fetch (undici) can throw setTypeOfService EINVAL from a socket callback
      // when a peer connection closes mid-request; nothing can catch it, and it would stop the validator.
      // That one failure only loses a single request, so log it and carry on; anything else still exits.
      process.on('uncaughtException', (err) => {
        if (err?.syscall === 'setTypeOfService') {
          console.error(`ignored a peer socket error: ${err.message}`);
          return;
        }
        console.error(err);
        process.exit(1);
      });
      await node.start();
      const shutdown = () => node.stop().then(() => process.exit(0));
      process.on('SIGINT', shutdown);
      process.on('SIGTERM', shutdown);
      return;
    }
    case 'canary': {
      const sub = positionals[0];
      if (sub === 'ladder') {
        const tw = await fetchJson(`${rpc}/tripwire`);
        console.log(`alert level ${tw.level} (${tw.levelName}); Ed25519 retired at ${tw.ed25519RetiredAt ?? 'not scheduled'}; bounties left ${tw.bountyPoolLeft}`);
        for (const r of tw.rungs) console.log(`  ${r.id.padEnd(10)} ${r.name.padEnd(32)} level ${r.level}  ${r.bounty.padEnd(24)} ${r.broken ? `BROKEN at block ${r.broken.height} by ${r.broken.by}` : 'intact'}`);
        return;
      }
      if (sub !== 'commit' && sub !== 'reveal') throw new Error('usage: cyvber canary ladder|commit|reveal');
      if (!values.key || !values.rung || !values.solution) throw new Error('--key, --rung and --solution are required');
      if (!normalizeSolution(values.rung, values.solution)) throw new Error(`--rung must be one of ${RUNG_IDS.join(', ')} with a hex solution ("<p hex>.<q hex>" for rsa-2048)`);
      const genesis = await fetchJson(`${rpc}/genesis`);
      const key = await loadSigningKey(values.key);
      if (!key.privateKey) throw new Error(`${values.key} is a multisig vault; claim from a single key`);
      const from = addressFromPublicKey(key.publicKey);
      const account = await fetchJson(`${rpc}/accounts/${from}`);
      const fields = sub === 'commit'
        ? { type: 'canary-commit', commitment: canaryCommitment(genesis.chainId, values.rung, from, values.solution) }
        : { type: 'canary-reveal', rung: values.rung, solution: values.solution };
      const tx = createTx({ chainId: genesis.chainId, fee: BigInt(genesis.minFee), nonce: account.pendingNonce, ...fields }, { privateKey: key.privateKey });
      const { hash } = await postTx(rpc, tx);
      console.log(sub === 'commit'
        ? `committed a claim on ${values.rung} (only a hash is public)\nreveal after ${genesis.tripwire?.revealDelayBlocks ?? 10} blocks with: cyvber canary reveal --key ${values.key} --rung ${values.rung} --solution <same>\ntx ${hash}`
        : `revealed the solution for ${values.rung}; if it is valid the bounty is paid in the next block\ntx ${hash}`);
      return;
    }
    case 'firewall': {
      const fw = await fetchJson(`${rpc}/firewall`);
      const r = fw.rules;
      console.log(`firewall ${fw.enabled ? 'ON' : 'OFF'} · layers: ${fw.layers.join(', ')}`);
      console.log(`  requests per minute per address: ${Object.entries(r.requestsPerMinute).map(([k, v]) => `${k} ${v}`).join(', ')}`);
      console.log(`  connections per address: ${r.maxConnectionsPerIp} · ban at ${r.banThresholdPoints} points, ${r.banMinutes[0]} min doubling up to ${r.banMinutes[1] / 60} h`);
      const st = fw.stats;
      console.log(`  dropped connections ${st.droppedConnections} · refused requests ${st.refusedRequests} · bans ${st.bans} · peer bans ${st.peerBans} · open connections ${st.openConnections}`);
      console.log(`  blocked now: ${fw.blocked.addresses} address(es), ${fw.blocked.peerIdentities} peer identit${fw.blocked.peerIdentities === 1 ? 'y' : 'ies'}`);
      for (const b of fw.blockedAddresses ?? []) console.log(`    ${b.address.padEnd(28)} ${Math.ceil(b.untilMs / 1000)} s left, strike ${b.strikes}, ${Object.entries(b.reasons).map(([k, v]) => `${k} ×${v}`).join(', ')}`);
      for (const b of fw.blockedPeers ?? []) console.log(`    peer ${b.identity}… ${Math.ceil(b.untilMs / 1000)} s left, ${Object.entries(b.reasons).map(([k, v]) => `${k} ×${v}`).join(', ')}`);
      return;
    }
    case 'asset': {
      const sub = positionals[0];
      if (sub === 'list') {
        const { assets } = await fetchJson(`${rpc}/assets`);
        if (!assets.length) console.log('no assets yet');
        for (const a of assets) console.log(`${a.symbol.padEnd(12)} ${a.class.padEnd(12)} supply ${a.supply}/${a.maxSupply}  holders ${a.holders}  admin keys ${a.adminKeys}${a.paused ? '  PAUSED' : ''}\n  ${a.assetId}  ${a.name}`);
        return;
      }
      if (sub === 'show' || sub === 'holdings') {
        if (!positionals[1]) throw new Error(`usage: cyvber asset ${sub} <${sub === 'show' ? 'assetId' : 'address'}>`);
        console.log(JSON.stringify(await fetchJson(`${rpc}/${sub === 'show' ? 'assets' : 'accounts'}/${positionals[1]}${sub === 'holdings' ? '/assets' : ''}`), null, 2));
        return;
      }
      if (sub !== 'send') throw new Error('usage: cyvber asset list|show|holdings|send');
      if (!values.key || !values.tx) throw new Error('--key and --tx <fields.json> are required');
      const fields = JSON.parse(fs.readFileSync(values.tx, 'utf8'));
      if (!RWA_TYPES.includes(fields.type)) throw new Error(`"type" must be one of: ${RWA_TYPES.join(', ')}`);
      for (const k of ['chainId', 'from', 'fee', 'nonce', 'signature']) delete fields[k]; // filled in here
      const { hash, genesis, tx } = await signAndSend(rpc, values.key, fields);
      console.log(`sent ${fields.type}\ntx ${hash}`);
      if (fields.type === 'asset-create') console.log(`assetId ${assetIdFor(genesis.chainId, addressFromPublicKey(tx.from), fields.symbol)}`);
      return;
    }
    case 'status': {
      console.log(JSON.stringify(await fetchJson(`${rpc}/status`), null, 2));
      return;
    }
    case 'balance': {
      if (!positionals[0]) throw new Error('address is required');
      const account = await fetchJson(`${rpc}/accounts/${positionals[0]}`);
      console.log(`${account.balanceFormatted} (nonce ${account.nonce})`);
      return;
    }
    case 'send': {
      if (!values.key || !values.to || !values.amount) throw new Error('--key, --to and --amount are required');
      const status = await fetchJson(`${rpc}/status`);
      const { decimals, symbol } = status.coin;
      const genesis = await fetchJson(`${rpc}/genesis`);
      const key = await loadSigningKey(values.key);
      if (!key.privateKey) throw new Error(`${values.key} is a multisig vault; use "cyvber multisig propose"`);
      const from = addressFromPublicKey(key.publicKey);
      const account = await fetchJson(`${rpc}/accounts/${from}`);
      const tx = createTransfer({
        chainId: status.chainId,
        privateKey: key.privateKey,
        to: values.to,
        amount: parseAmount(values.amount, decimals),
        fee: values.fee ? parseAmount(values.fee, decimals) : BigInt(genesis.minFee),
        nonce: account.pendingNonce,
        memo: values.memo,
      });
      const { hash } = await fetchJson(`${rpc}/txs`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(tx),
      });
      console.log(`sent ${values.amount} ${symbol} to ${values.to} (fee ${formatAmount(tx.fee, decimals)})\ntx ${hash}`);
      return;
    }
    case 'migrate-commit': {
      if (!values.key || !values['new-key'] || !values.payer) throw new Error('--key, --new-key and --payer are required');
      const oldKey = await loadSigningKey(values.key);
      const newKey = await loadSigningKey(values['new-key']);
      if (!PQ_KEY_TYPES.includes(keyTypeOf(newKey.publicKey))) throw new Error('--new-key must be a post-quantum key file');
      if (values.payer === values.key) throw new Error('--payer must be a different account: signing with the old key would reveal it');
      const genesis = await fetchJson(`${rpc}/genesis`);
      const commitment = migrationRevealCommitment(genesis.chainId, oldKey.publicKey, addressFromPublicKey(newKey.publicKey));
      const { hash } = await signAndSend(rpc, values.payer, { type: 'migrate-commit', commitment });
      console.log(`sent migrate-commit (only a hash; the old public key is still hidden)\ntx ${hash}\nthen, after the reveal delay: cyvber migrate --key ${values.key} --new-key ${values['new-key']}`);
      return;
    }
    case 'pq-commit': {
      if (!values.key || !values['new-key']) throw new Error('--key and --new-key are required');
      const genesis = await fetchJson(`${rpc}/genesis`);
      const oldKey = await loadSigningKey(values.key);
      const newKey = await loadSigningKey(values['new-key']);
      if (!PQ_KEY_TYPES.includes(keyTypeOf(newKey.publicKey))) throw new Error('--new-key must be a post-quantum key file');
      const from = addressFromPublicKey(oldKey.publicKey);
      const account = await fetchJson(`${rpc}/accounts/${from}`);
      const tx = createMigrationCommit({
        chainId: genesis.chainId,
        privateKey: oldKey.privateKey,
        pqPublicKey: newKey.publicKey,
        fee: BigInt(genesis.minFee),
        nonce: account.pendingNonce,
      });
      const { hash } = await fetchJson(`${rpc}/txs`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(tx),
      });
      console.log(`committed ${from}
       -> ${addressFromPublicKey(newKey.publicKey)} (${keyTypeOf(newKey.publicKey)})
only a hash is published; this account can now migrate only to that key
tx ${hash}`);
      return;
    }
    case 'migrate': {
      if (!values.key || !values['new-key']) throw new Error('--key and --new-key are required');
      const genesis = await fetchJson(`${rpc}/genesis`);
      const oldKey = await loadSigningKey(values.key);
      const newKey = await loadSigningKey(values['new-key']);
      const from = addressFromPublicKey(oldKey.publicKey);
      const account = await fetchJson(`${rpc}/accounts/${from}`);
      const tx = createMigration({
        chainId: genesis.chainId,
        privateKey: oldKey.privateKey,
        pqPrivateKey: newKey.privateKey,
        fee: BigInt(genesis.minFee),
        nonce: account.pendingNonce,
      });
      const { hash } = await fetchJson(`${rpc}/txs`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(tx),
      });
      console.log(`migrating ${from}\n       -> ${addressFromPublicKey(newKey.publicKey)} (${keyTypeOf(newKey.publicKey)})\nthe whole balance moves; the old key is locked afterwards\ntx ${hash}`);
      return;
    }
    case 'faucet': {
      if (!positionals[0]) throw new Error('address is required');
      const result = await fetchJson(`${rpc}/faucet`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ address: positionals[0] }),
      });
      console.log(`faucet sent ${result.amount} to ${positionals[0]}\ntx ${result.hash}`);
      return;
    }
    case 'vest': {
      if (!values.key || !values.to || !values.amount || values.lock === undefined || values.vest === undefined) throw new Error('--key, --to, --amount, --lock and --vest are required');
      const { coin } = await fetchJson(`${rpc}/status`);
      const fields = {
        type: 'vest', to: values.to, amount: parseAmount(values.amount, coin.decimals),
        lockMonths: months(values.lock, 'lock'), vestMonths: months(values.vest, 'vest'),
        ...(values['at-start'] ? { atStart: parseAmount(values['at-start'], coin.decimals) } : {}),
        ...(values.memo ? { memo: values.memo } : {}),
      };
      const { hash } = await signAndSend(rpc, values.key, fields);
      console.log(`granted ${values.amount} ${coin.symbol} to ${values.to}: locked ${values.lock} months, then unlocks monthly over ${values.vest} months\ntx ${hash}`);
      return;
    }
    case 'multisig': {
      const sub = positionals[0];
      if (sub === 'create') {
        if (!values.threshold || !values.keys || !values.out) throw new Error('--threshold, --keys and --out are required');
        const members = values.keys.split(',').map((f) => readKeyFile(f.trim()).publicKey);
        const publicKey = multisigKey(Number(values.threshold), members);
        const address = addressFromPublicKey(publicKey);
        writeKeyFile(values.out, { address, type: 'multisig', threshold: Number(values.threshold), members: members.map(addressFromPublicKey), publicKey });
        console.log(`wrote ${values.out}: ${values.threshold} of ${members.length} multisig\naddress ${address}\nThis file holds no private key; each member keeps their own key file.`);
        return;
      }
      if (sub === 'propose') {
        if (!values.vault || !values.to || !values.amount || !values.out) throw new Error('--vault, --to, --amount and --out are required');
        const vault = readKeyFile(values.vault);
        if (!parseMultisig(vault.publicKey)) throw new Error(`${values.vault} is not a multisig vault file`);
        const genesis = await fetchJson(`${rpc}/genesis`);
        const account = await fetchJson(`${rpc}/accounts/${vault.address}`);
        const vesting = values.lock !== undefined || values.vest !== undefined;
        const tx = createTx({
          type: vesting ? 'vest' : 'transfer', chainId: genesis.chainId, from: vault.publicKey, to: values.to,
          amount: parseAmount(values.amount, genesis.coin.decimals), fee: BigInt(genesis.minFee), nonce: account.pendingNonce,
          ...(vesting ? { lockMonths: months(values.lock ?? '0', 'lock'), vestMonths: months(values.vest ?? '0', 'vest') } : {}),
          ...(values.memo ? { memo: values.memo } : {}),
        });
        if (fs.existsSync(values.out)) throw new Error(`${values.out} already exists`);
        fs.writeFileSync(values.out, `${JSON.stringify({ tx, signatures: [] }, null, 2)}\n`);
        console.log(`wrote ${values.out}: ${values.amount} ${genesis.coin.symbol} from ${vault.address} to ${values.to}\nNow ${parseMultisig(vault.publicKey).threshold} members run: cyvber multisig sign --tx ${values.out} --key <their key file>`);
        return;
      }
      if (sub === 'sign') {
        if (!values.tx || !values.key) throw new Error('--tx and --key are required');
        const file = JSON.parse(fs.readFileSync(values.tx, 'utf8'));
        const ms = parseMultisig(file.tx.from);
        const key = await loadSigningKey(values.key);
        console.log(`signing: ${file.tx.type} of ${file.tx.amount} base units to ${file.tx.to} (nonce ${file.tx.nonce}, chain ${file.tx.chainId})`);
        file.signatures = [combineMultisig([...file.signatures, signMultisigPart(signingBytes(file.tx), file.tx.from, key.privateKey)])];
        fs.writeFileSync(values.tx, `${JSON.stringify(file, null, 2)}\n`);
        const have = file.signatures[0].split(',').length;
        console.log(`${have} of ${ms.threshold} signatures${have >= ms.threshold ? ` — ready: cyvber multisig submit --tx ${values.tx}` : ''}`);
        return;
      }
      if (sub === 'submit') {
        if (!values.tx) throw new Error('--tx is required');
        const file = JSON.parse(fs.readFileSync(values.tx, 'utf8'));
        const { hash } = await postTx(rpc, { ...file.tx, signature: combineMultisig(file.signatures) });
        console.log(`submitted\ntx ${hash}`);
        return;
      }
      throw new Error('use: multisig create | propose | sign | submit');
    }
    case 'export-pubkey': {
      if (!values.key || !values.out) throw new Error('--key and --out are required');
      const { address, type, publicKey } = readKeyFile(values.key);
      if (fs.existsSync(values.out)) throw new Error(`${values.out} already exists`);
      fs.writeFileSync(values.out, `${JSON.stringify({ address, type, publicKey }, null, 2)}\n`);
      console.log(`wrote ${values.out}: the public key of ${address} (no private key; safe to share)`);
      return;
    }
    case 'validators': {
      const v = await fetchJson(`${rpc}/validators`);
      console.log(`${v.active} active validators, quorum ${v.quorum}, minimum stake ${v.minStake}`);
      for (const x of v.validators) console.log(`${x.address}  ${x.status.padEnd(9)} ${x.genesis ? 'genesis' : x.stakeFormatted}${x.missedInARow ? `  missed ${x.missedInARow} in a row` : ''}`);
      if (v.banned.length) console.log(`banned for double-signing: ${v.banned.join(', ')}`);
      return;
    }
    case 'stake': {
      const sub = positionals[0];
      if (sub === 'request') {
        if (!values['validator-key'] || !values.operator || !values.amount || !values.out) throw new Error('--validator-key, --operator, --amount and --out are required');
        const vkey = await loadSigningKey(values['validator-key']);
        const { chainId, coin } = await fetchJson(`${rpc}/status`);
        const request = { chainId, validator: vkey.publicKey, operator: values.operator, amount: parseAmount(values.amount, coin.decimals).toString() };
        if (fs.existsSync(values.out)) throw new Error(`${values.out} already exists`);
        fs.writeFileSync(values.out, `${JSON.stringify({ ...request, validatorSignature: sign(validatorConsentBytes(request), vkey.privateKey) }, null, 2)}\n`);
        console.log(`wrote ${values.out}: request for ${values.amount} ${coin.symbol} of stake for validator ${addressFromPublicKey(vkey.publicKey)}, rewards to ${values.operator}\nIt holds no private key. Send it to the stake provider; they finish with: cyvber stake delegate --key <their key> --request ${values.out}`);
        return;
      }
      if (!values.key) throw new Error('--key (the owner account) is required');
      const { coin } = await fetchJson(`${rpc}/status`);
      if (sub === 'join') {
        if (!values['validator-key'] || !values.amount) throw new Error('--validator-key and --amount are required');
        const vkey = await loadSigningKey(values['validator-key']);
        const { hash } = await signAndSend(rpc, values.key, { type: 'validator-join', validator: vkey.publicKey, amount: parseAmount(values.amount, coin.decimals), extraSigners: { validatorSignature: vkey.privateKey } });
        console.log(`validator ${addressFromPublicKey(vkey.publicKey)} joins with ${values.amount} ${coin.symbol} staked\nRun its node with this validator key now: once the block is final it must sign blocks, or it gets jailed.\ntx ${hash}`);
        return;
      }
      if (sub === 'delegate') {
        if (!values.request) throw new Error('--request is required (made by the operator with "cyvber stake request")');
        const request = JSON.parse(fs.readFileSync(values.request, 'utf8'));
        const { chainId } = await fetchJson(`${rpc}/status`);
        if (request.chainId !== chainId) throw new Error(`this request is for ${request.chainId}, not ${chainId}`);
        console.log(`lending ${formatAmount(request.amount, coin.decimals)} ${coin.symbol} to validator ${addressFromPublicKey(request.validator)}; rewards go to ${request.operator}`);
        const { hash } = await signAndSend(rpc, values.key, { type: 'validator-join', validator: request.validator, operator: request.operator, amount: BigInt(request.amount), attach: { validatorSignature: request.validatorSignature } });
        console.log(`validator ${addressFromPublicKey(request.validator)} joins with delegated stake\nThe operator must run its node now: from the next block on it must sign.\ntx ${hash}`);
        return;
      }
      if (!['add', 'leave', 'unjail'].includes(sub)) throw new Error('use: stake join | request | delegate | add | leave | unjail');
      if (!values.validator) throw new Error('--validator <address> is required');
      const validator = await validatorKeyByAddress(rpc, values.validator);
      const type = { add: 'validator-bond', leave: 'validator-leave', unjail: 'validator-unjail' }[sub];
      const { hash } = await signAndSend(rpc, values.key, { type, validator, ...(sub === 'add' ? { amount: parseAmount(values.amount ?? '', coin.decimals) } : {}) });
      console.log(`${type} sent for ${values.validator}\ntx ${hash}`);
      return;
    }
    default:
      console.log(USAGE);
      if (command && command !== 'help') process.exitCode = 1;
  }
}

if (process.argv[1] && fs.realpathSync(process.argv[1]) === fileURLToPath(import.meta.url)) {
  main(process.argv.slice(2)).catch((err) => {
    console.error(`error: ${err.message}`);
    process.exit(1);
  });
}
