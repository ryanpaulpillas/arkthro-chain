// Chain state: accounts, total supply and the validator registry.
//
// Account: balance (BigInt base units), nonce, an optional pqCommit (hash of the post-quantum address
// the account has committed to migrate to), after a migration migratedTo, and optional vesting grants
// (part of the balance that unlocks month by month and can't be spent before).
//
// Validator registry, in join order: { key, owner, stake, status, missed, jailedUntil?, unbondAt?,
// genesis? }. status is 'active' (in the set that signs blocks), 'jailed' (removed for missing too
// many blocks; can return with validator-unjail) or 'unbonding' (left or slashed; the stake returns to
// the owner when the unbonding period ends). Keys caught double-signing are banned for good.
// Every active validator has one vote; joining needs at least minStake bonded.
//
// Q-Day Tripwire (when genesis.tripwire is set; see tripwire.js): canary = { pool, commits, broken,
// retire }. pool is the bounty CYVBER not yet paid (counted in supply); commits maps a claim
// commitment to the block it was made in; broken maps a rung to { height, by }; retire maps a key
// type to the block height from which the tripwire retired it.
//
// Real-world assets (ARS-1, see rwa.js): rwa = { assets, balances, kyc }, created by the first asset
// transaction and part of the state root from then on.
import { addressFromPublicKey, hashObject, keyTypeOf, sha256 } from './crypto.js';
import { migrationCommitment, migrationRevealCommitment } from './tx.js';
import { bountyPool, canaryCommitment, checkSolution, retirementFor } from './tripwire.js';
import { RWA_TYPES, applyRwaTx, emptyRwa, isEmptyRwa, migrateRwa } from './rwa.js';

// Average Gregorian month, so "12 months" means one year of block time.
export const MONTH_MS = 2_629_746_000;
const DAY_MS = 86_400_000;
export const MAX_GRANTS = 64;
const YEAR_MS = 12 * MONTH_MS;

// Validator rewards: genesis.rewards = { years: [units for year 1, year 2, ...], start? }. The pool is
// part of the fixed supply from genesis; it is released linearly within each year (front-loaded by
// making early years larger) and paid every block to the validators whose signatures the block carries.
export function rewardsReleased(rewards, t, genesisTimestamp) {
  if (!rewards) return 0n;
  const elapsed = Math.max(0, t - (rewards.start ?? genesisTimestamp));
  let released = 0n;
  rewards.years.forEach((amount, i) => {
    const into = elapsed - i * YEAR_MS;
    if (into >= YEAR_MS) released += BigInt(amount);
    else if (into > 0) released += (BigInt(amount) * BigInt(into)) / BigInt(YEAR_MS);
  });
  return released;
}

// Staking and penalty settings: genesis.staking overrides any of these.
export function stakingParams(genesis) {
  const one = 10n ** BigInt(genesis.coin.decimals);
  const p = genesis.staking ?? {};
  return {
    minStake: BigInt(p.minStake ?? (100_000n * one).toString()),
    minVestAmount: BigInt(p.minVestAmount ?? (100n * one).toString()), // smallest vesting grant (stops grant spam)
    maxValidators: p.maxValidators ?? 100,
    minValidators: p.minValidators ?? Math.min(4, genesis.validators.length),
    unbondingMs: p.unbondingMs ?? 14 * DAY_MS,
    jailMs: p.jailMs ?? DAY_MS,
    downtimeBlocks: p.downtimeBlocks ?? 500, // missed in a row before jailing
    downtimeSlashBps: p.downtimeSlashBps ?? 10, // 0.1% of stake
    doubleSignSlashBps: p.doubleSignSlashBps ?? 500, // 5% of stake, and banned for good
    evidenceMaxAgeBlocks: p.evidenceMaxAgeBlocks ?? 100_000,
  };
}

// Amount of a grant still locked at time t (ms).
export function lockedAmount(grant, t) {
  const amount = BigInt(grant.amount);
  const atStart = BigInt(grant.atStart ?? '0');
  const months = Math.max(0, Math.floor((t - grant.start) / MONTH_MS));
  if (grant.vestMonths === 0) return months >= grant.lockMonths ? 0n : amount - atStart;
  const steps = Math.min(Math.max(months - grant.lockMonths, 0), grant.vestMonths);
  return amount - atStart - ((amount - atStart) * BigInt(steps)) / BigInt(grant.vestMonths);
}

export function totalLocked(account, t) {
  return (account.vesting ?? []).reduce((sum, g) => sum + lockedAmount(g, t), 0n);
}

// When the last grant of an account is fully unlocked (ms), or null.
export function vestingEnd(grant) {
  return grant.start + (grant.lockMonths + grant.vestMonths) * MONTH_MS;
}

// Migration security rules. `policy` = { height, retiredAt }: the block the tx goes into and a
// function giving the block height at which a key type is retired (or undefined). Returns an error
// string or null.
//  - If the account committed to a post-quantum key (pq-commit), it can only migrate to that key.
//    So even an attacker who later recovers the Ed25519 key with a quantum computer can't redirect
//    the funds: new commitments are refused after the sunset, and the old one can't be changed.
//  - After its key type is retired, an account without a commitment can migrate only if its public
//    key was never published (it never signed a transaction), so a quantum attacker had nothing to work on.
//    It must first publish a migrate-commit (a hash binding its public key to the new address) at least
//    `revealDelay` blocks earlier: the migration reveals the public key, and a fast enough attacker could
//    otherwise derive the private key and race its own migration. A racer's commitment is always later.
//  - A migration can't move funds onto a key type that is itself retired.
export const MIGRATE_REVEAL_DELAY = 10;
export const MIGRATE_COMMIT_TTL = 100_000; // blocks a migrate-commit is kept

export function migrationError(account, tx, { height, retiredAt = () => undefined, migrationCommits = {}, revealDelay = MIGRATE_REVEAL_DELAY } = {}) {
  const from = addressFromPublicKey(tx.from);
  const target = addressFromPublicKey(tx.to);
  const targetRetired = retiredAt(keyTypeOf(tx.to));
  if (targetRetired && height >= targetRetired) return `${keyTypeOf(tx.to)} keys were retired at block ${targetRetired}; choose another post-quantum key type`;
  if (account.pqCommit) {
    return account.pqCommit === migrationCommitment(tx.chainId, from, target) ? null : 'this account committed to a different post-quantum key; it can only migrate to that key';
  }
  const sunset = retiredAt(keyTypeOf(tx.from));
  if (sunset && height >= sunset && account.nonce > 0) {
    return `this account's ${keyTypeOf(tx.from)} key was exposed and it made no migration commitment before block ${sunset}; it can't migrate safely`;
  }
  if (sunset && height >= sunset) {
    const at = migrationCommits[migrationRevealCommitment(tx.chainId, tx.from, target)];
    if (at === undefined) return `after block ${sunset} a never-used ${keyTypeOf(tx.from)} account must first send a migrate-commit (a hash only, from any account) and migrate ${revealDelay} blocks later`;
    if (height - at < revealDelay) return `too early: this account's migrate-commit is from block ${at}; migrate from block ${at + revealDelay}`;
  }
  return null;
}

export class State {
  constructor(accounts = new Map(), supply = 0n, validators = [], banned = new Set(), rewardPool = 0n, rewardsPaid = 0n, canary = null, rwa = null) {
    this.canary = canary;
    this.rwa = rwa;
    this.accounts = accounts;
    this.supply = supply;
    this.validators = validators;
    this.banned = banned;
    this.rewardPool = rewardPool; // validator rewards not yet paid out (counted in supply)
    this.rewardsPaid = rewardsPaid;
    this.migrationCommits = {}; // migrate-commit hash -> block height it was first made
  }

  static fromGenesis(genesis) {
    const state = new State();
    for (const [address, amount] of Object.entries(genesis.alloc)) {
      state.credit(address, BigInt(amount));
      state.supply += BigInt(amount);
    }
    for (const [address, grants] of Object.entries(genesis.vesting ?? {})) {
      const account = state.get(address);
      state.accounts.set(address, { ...account, vesting: grants.map((g) => normalizeGrant(g, genesis.timestamp)) });
    }
    state.validators = genesis.validators.map((key) => ({ key, owner: addressFromPublicKey(key), stake: 0n, status: 'active', missed: 0, genesis: true }));
    if (genesis.rewards) {
      state.rewardPool = genesis.rewards.years.reduce((sum, a) => sum + BigInt(a), 0n);
      state.supply += state.rewardPool;
    }
    if (genesis.tripwire) {
      state.canary = { pool: bountyPool(genesis.tripwire), commits: {}, broken: {}, retire: {} };
      state.supply += state.canary.pool;
    }
    return state;
  }

  clone() {
    const copy = new Map();
    for (const [address, account] of this.accounts) copy.set(address, { ...account });
    const state = new State(copy, this.supply, this.validators.map((v) => ({ ...v })), new Set(this.banned), this.rewardPool, this.rewardsPaid, cloneCanary(this.canary), this.rwa && structuredClone(this.rwa));
    state.migrationCommits = { ...this.migrationCommits };
    return state;
  }

  get(address) {
    return this.accounts.get(address) ?? { balance: 0n, nonce: 0 };
  }

  // Balance that can be spent at time t (not locked by vesting).
  spendable(address, t) {
    const account = this.get(address);
    const free = account.balance - totalLocked(account, t);
    return free > 0n ? free : 0n;
  }

  credit(address, amount) {
    if (amount === 0n) return;
    const account = this.get(address);
    this.accounts.set(address, { ...account, balance: account.balance + amount });
  }

  // Creates new coins, never beyond maxSupply. Returns the amount actually minted.
  mint(address, amount, maxSupply) {
    const minted = amount < maxSupply - this.supply ? amount : maxSupply - this.supply;
    if (minted <= 0n) return 0n;
    this.credit(address, minted);
    this.supply += minted;
    return minted;
  }

  // ---- validators ----

  activeValidators() {
    return this.validators.filter((v) => v.status === 'active').map((v) => v.key);
  }

  validator(key) {
    return this.validators.find((v) => v.key === key) ?? null;
  }

  // Where a validator's fees and rewards go: its operator if the stake was delegated, else its owner.
  rewardAddress(validatorKey) {
    const v = this.validator(validatorKey);
    return v ? v.operator ?? v.owner : addressFromPublicKey(validatorKey);
  }

  // Pays the validator rewards released up to this block, in equal shares, to the validators whose
  // signatures for the previous block this block carries (so being online is what earns).
  #payRewards(ctx, signers) {
    if (!ctx.rewards || !signers?.size) return;
    const due = rewardsReleased(ctx.rewards, ctx.timestamp, ctx.genesisTimestamp) - this.rewardsPaid;
    const eligible = [...signers].filter((k) => !this.banned.has(k));
    if (due <= 0n || !eligible.length) return;
    const share = (due < this.rewardPool ? due : this.rewardPool) / BigInt(eligible.length);
    if (share === 0n) return;
    for (const key of eligible) this.credit(this.rewardAddress(key), share);
    const paid = share * BigInt(eligible.length);
    this.rewardPool -= paid;
    this.rewardsPaid += paid;
  }

  #slash(v, bps) {
    const cut = (v.stake * BigInt(bps)) / 10_000n;
    v.stake -= cut;
    this.supply -= cut; // slashed CYVBER is burned
    return cut;
  }

  // Liveness and unbonding, after a block's transactions. `prevSet` = the validators that had to sign
  // the previous block; `signers` = those whose signatures this block carries for it.
  endBlock(ctx, { prevSet = null, signers = null } = {}) {
    const p = ctx.params;
    // Lapsed migrate-commits are dropped (kept in the order made, so only the oldest need checking).
    for (const [c, at] of Object.entries(this.migrationCommits)) {
      if (ctx.height - at < MIGRATE_COMMIT_TTL) break;
      delete this.migrationCommits[c];
    }
    // Lapsed tripwire commitments: removed, their deposits added to the bounty pool. Commitments are
    // kept in the order they were made, so only the oldest ever need checking.
    if (this.canary && ctx.tripwire) {
      for (const [c, entry] of Object.entries(this.canary.commits)) {
        if (ctx.height - entry.height < ctx.tripwire.commitTtlBlocks) break;
        this.canary.pool += BigInt(entry.deposit);
        delete this.canary.commits[c];
      }
    }
    if (prevSet && signers) {
      for (const key of prevSet) {
        const v = this.validator(key);
        if (!v || v.status !== 'active') continue;
        v.missed = signers.has(key) ? 0 : v.missed + 1;
        if (v.missed >= p.downtimeBlocks && this.activeValidators().length > p.minValidators) {
          this.#slash(v, p.downtimeSlashBps);
          v.status = 'jailed';
          v.jailedUntil = ctx.timestamp + p.jailMs;
          v.missed = 0;
        }
      }
    }
    this.#payRewards(ctx, signers);
    for (const v of this.validators.filter((x) => x.status === 'unbonding' && ctx.timestamp >= x.unbondAt)) {
      this.credit(v.owner, v.stake);
      this.validators.splice(this.validators.indexOf(v), 1);
    }
  }

  // ---- transactions ----

  // Applies a transaction that already passed checkTx. Throws if the state rejects it.
  // ctx = { height, timestamp, retiredAt, params, rewardAddress, chainId, tripwire }.
  applyTx(tx, ctx) {
    const from = addressFromPublicKey(tx.from);
    const sender = this.get(from);
    const fee = BigInt(tx.fee);
    const t = ctx.timestamp;
    if (sender.migratedTo) throw new Error(`account was migrated to ${sender.migratedTo}; use the new key`);
    if (tx.nonce !== sender.nonce) throw new Error(`bad nonce: expected ${sender.nonce}, got ${tx.nonce}`);
    const spend = (amount, what = 'insufficient balance') => {
      if (this.spendable(from, t) < amount + fee) {
        throw new Error(totalLocked(sender, t) > 0n && sender.balance >= amount + fee ? `${what}: part of this balance is still locked by vesting` : what);
      }
      const now = this.get(from);
      this.accounts.set(from, { ...now, balance: now.balance - amount - fee, nonce: now.nonce + 1 });
      this.credit(ctx.rewardAddress, fee);
    };
    // The owner (who staked) controls a validator; with delegated stake, so does its operator.
    const owned = ({ operatorToo = false } = {}) => {
      const v = this.validator(tx.validator);
      if (!v) throw new Error('unknown validator');
      if (v.owner !== from && !(operatorToo && v.operator === from)) throw new Error(`only the validator's ${operatorToo ? 'owner or operator' : 'owner'} account can do this`);
      return v;
    };
    const p = ctx.params;

    switch (tx.type) {
      case 'pq-commit':
        spend(0n, 'insufficient balance for the fee');
        this.accounts.set(from, { ...this.get(from), pqCommit: tx.commitment });
        return;

      case 'migrate-commit':
        spend(0n, 'insufficient balance for the fee');
        if (!Object.hasOwn(this.migrationCommits, tx.commitment)) this.migrationCommits[tx.commitment] = ctx.height; // the first one counts
        return;

      case 'migrate': {
        const policyError = migrationError(sender, tx, { ...ctx, migrationCommits: this.migrationCommits });
        if (policyError) throw new Error(policyError);
        const target = addressFromPublicKey(tx.to);
        const dest = this.get(target);
        if (dest.migratedTo) throw new Error('migration target is itself a migrated account');
        if (this.spendable(from, t) < fee) throw new Error('insufficient balance for the fee');
        const grants = [...(dest.vesting ?? []), ...(sender.vesting ?? [])];
        if (grants.length > MAX_GRANTS) throw new Error('the target account has too many vesting grants');
        this.accounts.set(from, { balance: 0n, nonce: sender.nonce + 1, migratedTo: target });
        this.accounts.set(target, { ...dest, balance: dest.balance + sender.balance - fee, ...(grants.length ? { vesting: grants } : {}) });
        this.credit(ctx.rewardAddress, fee);
        for (const v of this.validators) { // validator ownership and operation move too
          if (v.owner === from) v.owner = target;
          if (v.operator === from) v.operator = target;
        }
        if (this.rwa) migrateRwa(this.rwa, from, target); // asset units, KYC entries and asset roles too
        return;
      }

      case 'transfer':
      case 'vest': {
        const recipient = this.get(tx.to);
        if (recipient.migratedTo) throw new Error(`recipient migrated to ${recipient.migratedTo}; send there instead`);
        const amount = BigInt(tx.amount);
        if (tx.type === 'vest' && amount < p.minVestAmount) throw new Error(`a vesting grant must be at least ${p.minVestAmount} base units`);
        if (tx.type === 'vest' && (recipient.vesting?.length ?? 0) >= MAX_GRANTS) throw new Error('the recipient has too many vesting grants');
        spend(amount);
        this.credit(tx.to, amount);
        if (tx.type === 'vest') {
          const now = this.get(tx.to);
          const grant = normalizeGrant({ amount: tx.amount, atStart: tx.atStart, lockMonths: tx.lockMonths, vestMonths: tx.vestMonths }, t);
          this.accounts.set(tx.to, { ...now, vesting: [...(now.vesting ?? []), grant] });
        }
        return;
      }

      case 'validator-join': {
        const amount = BigInt(tx.amount);
        if (this.banned.has(tx.validator)) throw new Error('this validator key was banned for double-signing');
        if (this.validator(tx.validator)) throw new Error('this validator key is already registered');
        if (amount < p.minStake) throw new Error(`stake must be at least ${p.minStake} base units`);
        if (this.activeValidators().length >= p.maxValidators) throw new Error('the validator set is full');
        if (tx.operator && this.get(tx.operator).migratedTo) throw new Error('the operator account was migrated; use its new address');
        spend(amount);
        this.validators.push({ key: tx.validator, owner: from, ...(tx.operator && tx.operator !== from ? { operator: tx.operator } : {}), stake: amount, status: 'active', missed: 0 });
        return;
      }

      case 'validator-bond': {
        const v = owned();
        if (v.status === 'unbonding') throw new Error('this validator is leaving; it cannot take more stake');
        spend(BigInt(tx.amount));
        v.stake += BigInt(tx.amount);
        return;
      }

      case 'validator-leave': {
        const v = owned({ operatorToo: true });
        if (v.status === 'unbonding') throw new Error('this validator is already leaving');
        if (v.status === 'active' && this.activeValidators().length <= p.minValidators) throw new Error(`the network needs at least ${p.minValidators} validators`);
        spend(0n);
        v.status = 'unbonding';
        v.unbondAt = t + p.unbondingMs;
        return;
      }

      case 'validator-unjail': {
        const v = owned({ operatorToo: true });
        if (v.status !== 'jailed') throw new Error('this validator is not jailed');
        if (t < v.jailedUntil) throw new Error(`jailed until ${new Date(v.jailedUntil).toISOString()}`);
        if (!v.genesis && v.stake < p.minStake) throw new Error('stake is below the minimum; add stake with validator-bond first');
        if (this.activeValidators().length >= p.maxValidators) throw new Error('the validator set is full');
        spend(0n);
        v.status = 'active';
        v.missed = 0;
        delete v.jailedUntil;
        return;
      }

      case 'evidence': {
        const key = tx.voteA.validator;
        const v = this.validator(key);
        if (!v || this.banned.has(key)) throw new Error('no slashable validator for this evidence (unknown, already punished, or fully unbonded)');
        if (tx.voteA.height > ctx.height || tx.voteA.height < ctx.height - p.evidenceMaxAgeBlocks) throw new Error('evidence is too old or from the future');
        spend(0n);
        this.#slash(v, p.doubleSignSlashBps);
        this.banned.add(key);
        if (v.status !== 'unbonding') {
          v.status = 'unbonding';
          v.unbondAt = t + p.unbondingMs;
        }
        return;
      }

      case 'canary-commit': {
        if (!this.canary) throw new Error('this chain has no Q-Day Tripwire');
        if (Object.hasOwn(this.canary.commits, tx.commitment)) throw new Error('this commitment was already made');
        const deposit = ctx.tripwire.commitDeposit;
        spend(deposit, 'insufficient balance for the fee and the commitment deposit');
        this.canary.commits[tx.commitment] = { height: ctx.height, deposit: deposit.toString(), from };
        return;
      }

      case 'canary-reveal': {
        const tw = ctx.tripwire;
        if (!this.canary || !tw) throw new Error('this chain has no Q-Day Tripwire');
        if (!Object.hasOwn(tw.bounties, tx.rung)) throw new Error(`rung ${tx.rung} has no bounty on this chain`);
        const broken = this.canary.broken[tx.rung];
        if (broken) throw new Error(`rung ${tx.rung} was already broken at block ${broken.height}`);
        const commitment = canaryCommitment(ctx.chainId, tx.rung, from, tx.solution);
        const entry = this.canary.commits[commitment];
        if (entry === undefined) throw new Error('no canary-commit for this solution from this account; commit first');
        const at = entry.height;
        if (ctx.height - at < tw.revealDelayBlocks) throw new Error(`too early: reveal from block ${at + tw.revealDelayBlocks}`);
        if (!checkSolution(tx.rung, tx.solution)) throw new Error(`this solution does not break rung ${tx.rung}`);
        spend(0n, 'insufficient balance for the fee');
        const bounty = BigInt(tw.bounties[tx.rung]) < this.canary.pool ? BigInt(tw.bounties[tx.rung]) : this.canary.pool;
        this.canary.pool -= bounty;
        this.credit(from, bounty + BigInt(entry.deposit)); // the bounty, and the commitment deposit back
        delete this.canary.commits[commitment];
        this.canary.broken[tx.rung] = { height: ctx.height, by: from };
        const retire = retirementFor(tx.rung, ctx.height, tw);
        if (retire !== undefined && !(this.canary.retire.ed25519 <= retire)) this.canary.retire.ed25519 = retire;
        return;
      }

      default: {
        if (!RWA_TYPES.includes(tx.type)) throw new Error('unsupported transaction type');
        if (this.spendable(from, t) < fee) throw new Error('insufficient balance for the fee');
        this.rwa ??= emptyRwa();
        applyRwaTx(this.rwa, tx, from, { height: ctx.height, chainId: ctx.chainId, isMigrated: (a) => Boolean(this.get(a).migratedTo) });
        spend(0n, 'insufficient balance for the fee'); // asset fees are always paid in CYVBER
      }
    }
  }

  root() {
    const entries = [...this.accounts.entries()]
      .sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0))
      .map(([address, { balance, nonce, migratedTo, pqCommit, vesting }]) => {
        const entry = [address, balance.toString(), nonce];
        if (migratedTo) entry.push(migratedTo);
        else if (pqCommit) entry.push({ pqCommit });
        if (vesting?.length) entry.push({ vesting });
        return entry;
      });
    const validators = this.validators.map((v) => [sha256(v.key), v.owner, v.operator ?? null, v.stake.toString(), v.status, v.missed, v.jailedUntil ?? null, v.unbondAt ?? null, Boolean(v.genesis)]);
    return hashObject({
      supply: this.supply.toString(), accounts: entries, validators, banned: [...this.banned].map((k) => sha256(k)).sort(),
      rewards: [this.rewardPool.toString(), this.rewardsPaid.toString()],
      ...(this.canary ? { canary: { ...this.canary, pool: this.canary.pool.toString() } } : {}),
      ...(isEmptyRwa(this.rwa) ? {} : { rwa: this.rwa }),
      ...(Object.keys(this.migrationCommits).length ? { migrationCommits: this.migrationCommits } : {}),
    });
  }

  // Plain-JSON copy (for snapshots) and back.
  toJSON() {
    return {
      supply: this.supply.toString(),
      accounts: [...this.accounts].map(([a, acc]) => [a, { ...acc, balance: acc.balance.toString() }]),
      validators: this.validators.map((v) => ({ ...v, stake: v.stake.toString() })),
      banned: [...this.banned],
      rewardPool: this.rewardPool.toString(),
      rewardsPaid: this.rewardsPaid.toString(),
      ...(this.canary ? { canary: { ...this.canary, pool: this.canary.pool.toString() } } : {}),
      ...(this.rwa ? { rwa: this.rwa } : {}),
      ...(Object.keys(this.migrationCommits).length ? { migrationCommits: this.migrationCommits } : {}),
    };
  }

  static fromJSON(json) {
    const state = new State(
      new Map(json.accounts.map(([a, acc]) => [a, { ...acc, balance: BigInt(acc.balance) }])),
      BigInt(json.supply),
      json.validators.map((v) => ({ ...v, stake: BigInt(v.stake) })),
      new Set(json.banned),
      BigInt(json.rewardPool ?? '0'),
      BigInt(json.rewardsPaid ?? '0'),
      json.canary ? { ...cloneCanary({ ...json.canary, pool: 0n }), pool: BigInt(json.canary.pool) } : null,
      json.rwa ? structuredClone(json.rwa) : null,
    );
    state.migrationCommits = { ...(json.migrationCommits ?? {}) };
    return state;
  }
}

function cloneCanary(c) {
  return c && { pool: c.pool, commits: { ...c.commits }, broken: Object.fromEntries(Object.entries(c.broken).map(([k, v]) => [k, { ...v }])), retire: { ...c.retire } };
}

function normalizeGrant(g, defaultStart) {
  return {
    amount: String(g.amount),
    ...(g.atStart && g.atStart !== '0' ? { atStart: String(g.atStart) } : {}),
    lockMonths: g.lockMonths ?? 0,
    vestMonths: g.vestMonths ?? 0,
    start: g.start ?? defaultStart,
  };
}
