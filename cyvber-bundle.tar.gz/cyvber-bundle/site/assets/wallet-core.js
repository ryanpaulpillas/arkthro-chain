// CYVBER browser wallet core: post-quantum keys, addresses and signed transactions, compatible
// with the node and the command-line wallet (same key-file format, same signing bytes).
// Crypto: @noble/post-quantum (ML-DSA, FIPS 204) and @noble/curves (Ed25519), served from
// assets/vendor through the page's import map.
import { ml_dsa65, ml_dsa87 } from '@noble/post-quantum/ml-dsa.js';
import { ed25519 } from '@noble/curves/ed25519.js';
import { sha256 } from '@noble/hashes/sha2.js';
import { bytesToHex, hexToBytes, utf8ToBytes, concatBytes } from '@noble/hashes/utils.js';

// Key types the browser can create and sign with. (Hash-based SLH-DSA keys are made with the
// command-line wallet: signing them takes seconds and is meant for cold storage.)
export const TYPES = {
  'ml-dsa-87': { label: 'mldsa87:', impl: ml_dsa87, oid: '0609608648016503040313', name: 'ML-DSA-87 · NIST category 5' },
  'ml-dsa-65': { label: 'mldsa65:', impl: ml_dsa65, oid: '0609608648016503040312', name: 'ML-DSA-65 · NIST category 3' },
};
export const DEFAULT_TYPE = 'ml-dsa-87';

// ---- DER (just enough for SPKI and seed-only PKCS#8) ----
function derLength(n) {
  if (n < 0x80) return Uint8Array.of(n);
  const bytes = [];
  for (let v = n; v > 0; v >>= 8) bytes.unshift(v & 0xff);
  return Uint8Array.of(0x80 | bytes.length, ...bytes);
}
const tlv = (tag, body) => concatBytes(Uint8Array.of(tag), derLength(body.length), body);
const spkiDer = (spec, rawPublicKey) => tlv(0x30, concatBytes(tlv(0x30, hexToBytes(spec.oid)), tlv(0x03, concatBytes(Uint8Array.of(0), rawPublicKey))));
const pkcs8SeedDer = (spec, seed) => tlv(0x30, concatBytes(Uint8Array.of(0x02, 0x01, 0x00), tlv(0x30, hexToBytes(spec.oid)), tlv(0x04, tlv(0x80, seed))));

// The 32-byte seed inside a PKCS#8 ML-DSA key: either the seed-only form ([0] seed) or OpenSSL's
// "both" form (SEQUENCE { OCTET STRING seed, OCTET STRING expanded key }).
function seedFromPkcs8(der, spec) {
  const oid = hexToBytes(spec.oid);
  let at = -1;
  for (let i = 0; i + oid.length <= der.length; i++) if (oid.every((b, j) => der[i + j] === b)) { at = i + oid.length; break; }
  if (at < 0) throw new Error('key file is not for this key type');
  for (let i = at; i + 33 < der.length; i++) {
    if ((der[i] === 0x80 || der[i] === 0x04) && der[i + 1] === 0x20) return der.slice(i + 2, i + 34);
  }
  throw new Error('could not find the key seed in this key file');
}

// ---- keys and addresses (same rules as the node) ----
export function addressOf(publicKey) {
  const colon = publicKey.indexOf(':');
  const bytes = colon > 0
    ? concatBytes(utf8ToBytes(publicKey.slice(0, colon + 1)), hexToBytes(publicKey.slice(colon + 1)))
    : hexToBytes(publicKey);
  return 'cy' + bytesToHex(sha256(bytes));
}

function fromSeed(type, seed) {
  if (type === 'ed25519') {
    const publicKey = bytesToHex(ed25519.getPublicKey(seed));
    return { type, seed, publicKey, address: addressOf(publicKey), sign: (msg) => ed25519.sign(msg, seed) };
  }
  const spec = TYPES[type];
  if (!spec) throw new Error(`the browser wallet can't use ${type} keys; use the command-line wallet`);
  const keys = spec.impl.keygen(seed);
  const publicKey = spec.label + bytesToHex(spkiDer(spec, keys.publicKey));
  return { type, seed, publicKey, address: addressOf(publicKey), sign: (msg) => spec.impl.sign(msg, keys.secretKey) };
}

export function createWallet(type = DEFAULT_TYPE) {
  return fromSeed(type, crypto.getRandomValues(new Uint8Array(32)));
}

// Reads a key file made by `cyvber keygen` (or exported here).
export function walletFromKeyFile(file) {
  if (file?.encrypted && !file.privateKey) throw new Error('This key file is passphrase-protected (a vault key). Vault keys stay offline: use them with the command-line wallet, not in a browser.');
  const priv = file?.privateKey;
  if (typeof priv !== 'string') throw new Error('not a CYVBER key file (no privateKey)');
  const entry = Object.entries(TYPES).find(([, spec]) => priv.startsWith(spec.label));
  let wallet;
  if (entry) {
    const [type, spec] = entry;
    wallet = fromSeed(type, seedFromPkcs8(hexToBytes(priv.slice(spec.label.length)), spec));
  } else if (/^[0-9a-f]{64}$/.test(priv)) {
    wallet = fromSeed('ed25519', hexToBytes(priv));
  } else {
    throw new Error('this key type is not supported in the browser (use the command-line wallet)');
  }
  if (file.publicKey && file.publicKey !== wallet.publicKey) throw new Error('key file is inconsistent: public key does not match private key');
  return wallet;
}

// Same JSON shape as the command-line wallet's key files.
export function toKeyFile(wallet) {
  const privateKey = wallet.type === 'ed25519' ? bytesToHex(wallet.seed) : TYPES[wallet.type].label + bytesToHex(pkcs8SeedDer(TYPES[wallet.type], wallet.seed));
  return { address: wallet.address, type: wallet.type, publicKey: wallet.publicKey, privateKey };
}

// ---- amounts ----
export function parseAmount(text, decimals = 18) {
  if (typeof text !== 'string' || !/^\d+(\.\d+)?$/.test(text.trim())) throw new Error('enter an amount like 10 or 2.5');
  const [whole, frac = ''] = text.trim().split('.');
  if (frac.length > decimals) throw new Error(`at most ${decimals} decimal places`);
  return BigInt(whole) * 10n ** BigInt(decimals) + BigInt(frac.padEnd(decimals, '0') || '0');
}
export function formatUnits(units, decimals = 18, maxFrac = 6) {
  const v = BigInt(units), base = 10n ** BigInt(decimals);
  const frac = (v % base).toString().padStart(decimals, '0').slice(0, maxFrac).replace(/0+$/, '');
  return `${(v / base).toLocaleString('en-US')}${frac ? '.' + frac : ''}`;
}

// ---- transactions (signing bytes = canonical JSON, keys sorted, as in the node) ----
export function canonical(value) {
  if (value === null || typeof value !== 'object') return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(canonical).join(',')}]`;
  const keys = Object.keys(value).filter((k) => value[k] !== undefined).sort();
  return `{${keys.map((k) => `${JSON.stringify(k)}:${canonical(value[k])}`).join(',')}}`;
}

export function buildTransfer(wallet, { chainId, to, amount, fee, nonce, memo }) {
  const body = { type: 'transfer', chainId, from: wallet.publicKey, to, amount: amount.toString(), fee: fee.toString(), nonce, ...(memo ? { memo } : {}) };
  return { ...body, signature: bytesToHex(wallet.sign(utf8ToBytes(canonical(body)))) };
}

// Moves the whole `oldWallet` account to `newWallet`'s key; signed by both.
export function buildMigration(oldWallet, newWallet, { chainId, fee, nonce }) {
  const body = { type: 'migrate', chainId, from: oldWallet.publicKey, to: newWallet.publicKey, fee: fee.toString(), nonce };
  const bytes = utf8ToBytes(canonical(body));
  return { ...body, signature: bytesToHex(oldWallet.sign(bytes)), pqSignature: bytesToHex(newWallet.sign(bytes)) };
}
