// CYVBER assistant chat bubble. Talks to the cyvber-assistant service, which answers from this
// website's pages and live network status. Loaded on every page by site.js.
(function () {
  const ENDPOINT = (typeof ON_CYVBER_IO !== 'undefined' && ON_CYVBER_IO) ? '/api/assistant' : 'http://127.0.0.1:8787/api/assistant';
  const STORE = 'cyvber-assistant-chat';
  const SUGGESTIONS = ['What is CYVBER?', 'Is CYVBER quantum-resistant?', 'How do I get test CYV?', 'Can I buy CYVBER?'];
  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  // Tiny, safe formatter: escape everything, then allow **bold**, `code`, links to this site's pages and https links.
  function format(text) {
    return esc(text)
      .replace(/\*\*([^*]+)\*\*/g, '<b>$1</b>')
      .replace(/`([^`]+)`/g, '<code>$1</code>')
      .replace(/\[([^\]]+)\]\(([a-z0-9-]+\.html(?:#[a-z0-9-]+)?)\)/gi, '<a href="$2">$1</a>')
      .replace(/\[([^\]]+)\]\((https:\/\/[^\s)]+)\)/gi, '<a href="$2" target="_blank" rel="noopener">$1 ↗</a>')
      .replace(/\n/g, '<br>');
  }

  let history = [];
  try { history = JSON.parse(sessionStorage.getItem(STORE) || '[]'); } catch {}
  const save = () => { try { sessionStorage.setItem(STORE, JSON.stringify(history.slice(-20))); } catch {} };

  const root = document.createElement('div');
  root.className = 'ai';
  root.innerHTML = `
    <button class="ai-fab" type="button" aria-label="Ask the CYVBER assistant" aria-expanded="false" aria-controls="aiPanel">
      <img src="assets/cyvber-mark-128.png" alt="" width="30" height="30"><span>Ask CYVBER AI</span>
    </button>
    <section class="ai-panel" id="aiPanel" role="dialog" aria-label="CYVBER assistant" hidden>
      <header class="ai-head">
        <img src="assets/cyvber-mark-128.png" alt="" width="28" height="28">
        <div><b>CYVBER assistant</b><small>Answers from this website · AI can make mistakes</small></div>
        <button class="ai-x" type="button" aria-label="Close">×</button>
      </header>
      <div class="ai-log" aria-live="polite"></div>
      <div class="ai-suggest"></div>
      <form class="ai-form">
        <input class="ai-input" maxlength="1000" placeholder="Ask about CYVBER…" aria-label="Your question" autocomplete="off">
        <button class="btn primary small" type="submit">Ask</button>
      </form>
      <p class="ai-foot">Never share your private key or key file, here or anywhere. <button class="ai-clear" type="button">Clear chat</button></p>
    </section>`;
  document.body.appendChild(root);

  const fab = root.querySelector('.ai-fab'), panel = root.querySelector('.ai-panel'), log = root.querySelector('.ai-log');
  const form = root.querySelector('.ai-form'), input = root.querySelector('.ai-input'), suggest = root.querySelector('.ai-suggest');

  function bubble(role, text) {
    const div = document.createElement('div');
    div.className = `ai-msg ${role}`;
    div.innerHTML = role === 'assistant' ? format(text) : esc(text);
    log.appendChild(div);
    log.scrollTop = log.scrollHeight;
    return div;
  }
  function renderAll() {
    log.innerHTML = '';
    if (!history.length) bubble('assistant', 'Hi! I can answer questions about CYVBER: the CYVBER coin, the wallet, validators, quantum security and the roadmap.');
    history.forEach((m) => bubble(m.role, m.content));
    suggest.innerHTML = history.length ? '' : SUGGESTIONS.map((q) => `<button type="button">${esc(q)}</button>`).join('');
  }
  function open(state) {
    panel.hidden = !state;
    fab.setAttribute('aria-expanded', String(state));
    root.classList.toggle('open', state);
    if (state) { renderAll(); input.focus(); }
  }
  fab.addEventListener('click', () => open(panel.hidden));
  root.querySelector('.ai-x').addEventListener('click', () => open(false));
  root.querySelector('.ai-clear').addEventListener('click', () => { history = []; save(); renderAll(); });
  suggest.addEventListener('click', (e) => { if (e.target.tagName === 'BUTTON') ask(e.target.textContent); });
  form.addEventListener('submit', (e) => { e.preventDefault(); if (input.value.trim()) ask(input.value.trim()); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !panel.hidden) open(false); });

  let busy = false;
  async function ask(question) {
    if (busy) return;
    busy = true;
    input.value = '';
    suggest.innerHTML = '';
    history.push({ role: 'user', content: question });
    bubble('user', question);
    const out = bubble('assistant', '');
    out.classList.add('typing');
    let answer = '';
    try {
      const res = await fetch(ENDPOINT, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ messages: history.slice(-20) }) });
      if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        throw new Error(body.error || `The assistant is unavailable (HTTP ${res.status}).`);
      }
      const reader = res.body.getReader();
      const dec = new TextDecoder();
      let buf = '';
      for (;;) {
        const { value, done } = await reader.read();
        if (done) break;
        buf += dec.decode(value, { stream: true });
        let i;
        while ((i = buf.indexOf('\n\n')) >= 0) {
          const line = buf.slice(0, i); buf = buf.slice(i + 2);
          if (!line.startsWith('data: ')) continue;
          const ev = JSON.parse(line.slice(6));
          if (ev.error) throw new Error(ev.error);
          if (ev.text) { answer += ev.text; out.innerHTML = format(answer); log.scrollTop = log.scrollHeight; }
        }
      }
      if (!answer) throw new Error('No answer came back. Please try again.');
      history.push({ role: 'assistant', content: answer });
      save();
    } catch (err) {
      history.pop(); // drop the unanswered question so the conversation stays well-formed
      out.classList.add('err');
      out.textContent = err.message === 'Failed to fetch' ? 'The assistant is offline. (Locally, start it with "npm run dev" in the cyvber-assistant folder.)' : err.message;
    } finally {
      out.classList.remove('typing');
      busy = false;
    }
  }
})();
