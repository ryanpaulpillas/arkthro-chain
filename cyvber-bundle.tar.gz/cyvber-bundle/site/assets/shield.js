// Home page: CYVBER Shield, live from the node (GET /status for the tunnels and Dark Gate, GET /firewall
// for the firewall's counters). Uses site.js helpers.
(function () {
  const $id = (id) => document.getElementById(id);
  if (!$id('shield')) return;
  const n = (v) => Number(v).toLocaleString('en-US');
  async function refresh() {
    let status, fw;
    try {
      [status, fw] = await Promise.all([getJson('/status'), getJson('/firewall')]);
    } catch {
      $id('shieldState').textContent = '· the network is not reachable right now';
      return;
    }
    const p2p = status.p2p ?? {};
    const hybrid = /X25519/.test(p2p.keyExchange ?? '');
    $id('shieldTunnel').textContent = hybrid ? 'ML-KEM + X25519' : (p2p.keyExchange ? 'ML-KEM only' : '–');
    $id('shieldGate').textContent = p2p.stealth ? 'On' : 'Off';
    $id('shieldFirewall').textContent = fw.enabled ? `${fw.layers.length} layers on` : 'Off';
    const blocked = fw.blocked.addresses + fw.blocked.peerIdentities;
    $id('shieldBlocked').textContent = blocked ? `${n(blocked)} blocked` : 'None';
    $id('shieldState').textContent = fw.enabled && hybrid ? '· protecting this node' : '· partly active';
    const st = fw.stats;
    $id('shieldCounters').textContent = `Blocked now: ${n(fw.blocked.addresses)} address${fw.blocked.addresses === 1 ? '' : 'es'} and ${n(fw.blocked.peerIdentities)} node identit${fw.blocked.peerIdentities === 1 ? 'y' : 'ies'} · since start: ${n(st.refusedRequests)} requests refused, ${n(st.droppedConnections)} connections dropped, ${n(st.bans + st.peerBans)} bans`;
  }
  refresh();
  setInterval(refresh, 5000);
})();
