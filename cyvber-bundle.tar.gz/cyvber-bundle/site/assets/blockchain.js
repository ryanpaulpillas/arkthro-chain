// Blockchain page: the latest blocks drawn as a linked chain, and the newest block taken apart
// field by field. Uses helpers from site.js (getJson, esc, short, ago, explorer, names).
(function () {
  const strip = document.getElementById('chainStrip');
  const anatomy = document.getElementById('anatomy');
  let shownHeight = 0;

  const link = (route, text, cls = '') => `<a class="${cls}" href="${explorer(route)}" target="_blank" rel="noopener">${text}</a>`;
  const nameOf = (address) => names.get(address) || short(address);

  function renderStrip(blocks, validatorCount) {
    const oldestFirst = [...blocks].reverse();
    strip.innerHTML = oldestFirst.map((b, i) => `
      ${i ? '<div class="chain-link" aria-hidden="true"></div>' : ''}
      <div class="chain-block${i === oldestFirst.length - 1 ? ' is-newest' : ''}">
        <div class="h">${link(`#/block/${b.height}`, `#${b.height.toLocaleString('en-US')}`)}</div>
        <div class="muted" data-ts="${b.timestamp}">${ago(b.timestamp)}</div>
        <div class="kv"><span>${b.txCount} tx</span><span>${b.signatures.length}/${validatorCount} signed</span></div>
        <div class="hash" title="${esc(b.hash)}">hash ${esc(b.hash.slice(0, 10))}…</div>
        ${i === oldestFirst.length - 1 ? '<div class="badge ok" style="margin-top:8px">Newest</div>' : ''}
      </div>`).join('');
    strip.scrollLeft = strip.scrollWidth;
  }

  function row(field, value, meaning) {
    return `<div class="anat-row"><div><b>${field}</b></div><div><div class="v">${value}</div><p>${meaning}</p></div></div>`;
  }

  function renderAnatomy(b, validatorCount) {
    const h = b.header;
    const prev = h.height > 1 ? link(`#/block/${h.height - 1}`, `${esc(h.prevHash.slice(0, 24))}…`, 'mono') : `<span class="mono">${esc(h.prevHash.slice(0, 24))}…</span>`;
    const lastSigs = b.lastCommit?.precommits?.length ?? 0;
    const sigs = b.commit.precommits.length;
    anatomy.innerHTML = `
      <div class="anat-head">Header <span class="muted">· links the block into the chain</span></div>
      ${row('Height', `${link(`#/block/${h.height}`, `#${h.height.toLocaleString('en-US')}`)}`, 'Its position in the chain, counting from the first block.')}
      ${row('Time', `${new Date(h.timestamp).toLocaleString()} <span class="muted">(${ago(h.timestamp)})</span>`, 'Always later than the block before; validators reject blocks from the future.')}
      ${row('Previous block', prev, 'The fingerprint of the block before. This is the link that makes it a chain.')}
      ${row('Proposer', esc(nameOf(b.proposerAddress)), 'The validator whose turn it was to build this block. It receives the block\'s fees.')}
      ${row('Transactions root', `<span class="mono">${esc(h.txRoot.slice(0, 24))}…</span>`, 'One fingerprint covering every transaction inside, so none can be added, removed or changed.')}
      ${row('State root', `<span class="mono">${esc(h.stateRoot.slice(0, 24))}…</span>`, 'A fingerprint of every balance after this block. Every validator computes it independently and must get the same result.')}
      ${row('Validator set', `<span class="mono">${esc(h.validatorsHash.slice(0, 24))}…</span>`, 'A fingerprint of who must sign this block. It changes when validators join, leave or are penalized.')}
      <div class="anat-head">Transactions <span class="muted">· what the block carries</span></div>
      ${row('Transactions', b.txs.length ? `${b.txs.length} transaction${b.txs.length === 1 ? '' : 's'}` : '0 <span class="muted">(an empty "heartbeat" block)</span>', 'Transfers, vesting grants, staking and other actions, applied in order.')}
      ${row('Previous block\'s signatures', h.height > 1 ? `${lastSigs} of ${validatorCount}` : '<span class="muted">none (first block)</span>', 'Records which validators signed the block before, so the chain knows who is online and can penalize long absences.')}
      <div class="anat-head">Proof <span class="muted">· why it can't be undone</span></div>
      ${row('Block hash', `<span class="mono">${esc(b.hash.slice(0, 24))}…</span>`, 'The block\'s own fingerprint, computed from its header. The next block will point to it.')}
      ${row('Commit certificate', `<b>${sigs} signatures</b> <span class="badge ok">Final</span>`, `More than two thirds of the validators signed this exact block with post-quantum keys. Any node can check these ${sigs} signatures itself.`)}`;
  }

  async function refresh() {
    try {
      const status = await getJson('/status');
      if (status.height === shownHeight) return;
      const [blocks, latest] = await Promise.all([getJson('/blocks?limit=5'), getJson('/blocks/latest')]);
      shownHeight = status.height;
      renderStrip(blocks, status.validators.length);
      renderAnatomy(latest, status.validators.length);
    } catch {
      if (!shownHeight) {
        strip.innerHTML = '<div class="muted">The network isn\'t reachable right now.</div>';
        anatomy.innerHTML = '<div class="anat-row"><span class="muted">The network isn\'t reachable right now.</span></div>';
      }
    }
  }

  refresh();
  setInterval(refresh, 2000);
})();
