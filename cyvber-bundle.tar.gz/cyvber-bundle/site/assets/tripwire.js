// Blockchain page: the Q-Day tripwire, live from the node (GET /tripwire). Uses site.js helpers.
(function () {
  const rows = document.getElementById('twRungs');
  const level = document.getElementById('twLevel');
  const note = document.getElementById('twNote');
  const box = document.getElementById('twStatus');
  if (!rows) return;
  const IF_BROKEN = { 1: 'Watch', 2: 'Prepare', 3: 'Sunset' };
  const nice = (s) => String(s).replace(/^(\d+)(\.\d+)?/, (m, int, frac) => BigInt(int).toLocaleString('en-US') + (frac ?? ''));
  const strength = (r) => (r.kind === 'rsa' ? 'RSA-2048 (factoring)' : `${r.bits}-bit curve (${r.name})`);
  async function refresh() {
    let t;
    try {
      t = await getJson('/tripwire');
    } catch (err) {
      note.textContent = /no Q-Day/.test(err.message) ? 'This network runs without the tripwire.' : 'The network is not reachable right now.';
      return;
    }
    level.textContent = `${t.level} · ${t.levelName === 'none' ? 'all clear' : t.levelName}`;
    box.dataset.level = String(t.level);
    note.textContent = t.level === 0
      ? `Every bait key is intact. ${nice(t.bountyPoolLeft)} in bounties waiting.`
      : t.ed25519RetiredAt ? `Classical (Ed25519) keys retired from block ${t.ed25519RetiredAt.toLocaleString('en-US')}.` : 'A weak key has fallen; recorded, no rule change.';
    rows.innerHTML = t.rungs.map((r) => `<tr><td class="mono">${esc(r.id)}</td><td>${esc(strength(r))}</td><td>Level ${r.level} · ${IF_BROKEN[r.level]}</td><td>${esc(nice(r.bounty))}</td><td>${r.broken ? `<span class="badge out">Broken at block ${r.broken.height}</span>` : '<span class="badge ok">Intact</span>'}</td></tr>`).join('');
  }
  refresh();
  setInterval(refresh, 5000);
})();
