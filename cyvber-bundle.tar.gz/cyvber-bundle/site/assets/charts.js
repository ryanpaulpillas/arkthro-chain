// Small dependency-free SVG charts for the CYVBER site, plus the draft CYVBER allocation.
// Categorical colors: validated 8-slot palette (dark and light steps), assigned in fixed order.
(function () {
  const PALETTE = {
    dark: ['#3987e5', '#d95926', '#199e70', '#c98500', '#d55181', '#008300', '#9085e9', '#e66767'],
    light: ['#2a78d6', '#eb6834', '#1baf7a', '#eda100', '#e87ba4', '#008300', '#6250d6', '#e34948'],
  };
  const mode = () => (document.documentElement.dataset.theme === 'light' ? 'light' : 'dark');
  const color = (i) => PALETTE[mode()][i];
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const NS = 'http://www.w3.org/2000/svg';

  // Planned allocation and unlock schedule (decided 2026-10-13, shortened and smoothed the same day).
  // atLaunch: share of the allocation free at mainnet; lock: months fully locked; months: equal monthly
  // unlocks after the lock (no lump sum when a lock ends). Public distribution only after legal review.
  const ALLOCATION = [
    { name: 'Ecosystem & community', pct: 30, atLaunch: 0.10, lock: 0, months: 36, release: '10% at launch, the rest monthly over 3 years, for grants, developer programs and community rewards' },
    { name: 'Treasury & reserve', pct: 20, atLaunch: 0, lock: 6, months: 48, release: 'Locked 6 months, then at most 5% of the total supply per year, by governance decision' },
    { name: 'Team', pct: 15, atLaunch: 0, lock: 12, months: 24, release: 'Core team and people who join later; locked 1 year, then monthly over 2 years' },
    { name: 'Validator & staking incentives', pct: 12, atLaunch: 0, lock: 0, months: 48, yearly: [24, 18, 12, 6], release: 'Paid by the chain to the validators that sign blocks, front-loaded over 4 years: 24M, 18M, 12M, 6M CYV' },
    { name: 'Public distribution', pct: 10, atLaunch: 1, lock: 0, months: 0, release: 'At mainnet, only if legal review clears it; terms to be published' },
    { name: 'Strategic partners & advisors', pct: 8, atLaunch: 0, lock: 6, months: 18, release: 'Locked 6 months, then monthly over 18 months (2 years in total)' },
    { name: 'Liquidity', pct: 5, atLaunch: 1, lock: 0, months: 0, release: 'At mainnet launch, for exchange liquidity' },
  ];
  // yearly: a front-loaded release, as amounts per year (each year released evenly month by month).
  const yearlyShare = (yearly, m) => yearly.reduce((s, y, i) => s + y * Math.min(1, Math.max(0, (m - 12 * i) / 12)), 0) / yearly.reduce((s, y) => s + y, 0);
  const unlockedPct = (a, m) => a.pct * (a.yearly ? yearlyShare(a.yearly, m) : a.atLaunch + (1 - a.atLaunch) * (a.months ? Math.min(1, Math.max(0, m - a.lock) / a.months) : 0));
  const unlockedTotal = (m) => ALLOCATION.reduce((sum, a) => sum + unlockedPct(a, m), 0);
  const FULL_UNLOCK_MONTH = Math.max(...ALLOCATION.map((a) => a.lock + a.months));
  const SUPPLY = 500_000_000;
  const millions = (pct) => (SUPPLY * pct / 1e8).toLocaleString('en-US', { maximumFractionDigits: 1 }); // % of supply -> millions

  // ---- tooltip shared by all charts ----
  let tip;
  function tooltip() {
    if (tip) return tip;
    tip = document.createElement('div');
    tip.className = 'chart-tip';
    tip.setAttribute('role', 'status');
    document.body.appendChild(tip);
    return tip;
  }
  function showTip(html, x, y) {
    const t = tooltip();
    t.innerHTML = html;
    t.style.display = 'block';
    const w = t.offsetWidth, h = t.offsetHeight;
    t.style.left = `${Math.min(window.innerWidth - w - 8, Math.max(8, x - w / 2))}px`;
    t.style.top = `${Math.max(8, y - h - 14)}px`;
  }
  function hideTip() { if (tip) tip.style.display = 'none'; }

  // ---- part-to-whole: one horizontal stacked bar with 2px gaps ----
  function stackedBar(el, parts, { height = 28 } = {}) {
    const total = parts.reduce((s, p) => s + p.value, 0);
    el.innerHTML = '';
    el.classList.add('stack');
    el.style.height = `${height}px`;
    parts.forEach((p, i) => {
      const seg = document.createElement('div');
      seg.className = 'stack-seg';
      seg.style.flex = `${p.value} 1 0`;
      seg.style.background = color(i);
      seg.tabIndex = 0;
      seg.setAttribute('aria-label', `${p.label}: ${p.detail}`);
      const show = () => { const r = seg.getBoundingClientRect(); showTip(`<b>${esc(p.label)}</b><br>${esc(p.detail)}`, r.left + r.width / 2, r.top); };
      seg.addEventListener('mouseenter', show);
      seg.addEventListener('focus', show);
      seg.addEventListener('mouseleave', hideTip);
      seg.addEventListener('blur', hideTip);
      el.appendChild(seg);
    });
    return total;
  }

  function allocationLegend(el) {
    el.innerHTML = ALLOCATION.map((a, i) => `<li><i style="background:${color(i)}"></i><span>${esc(a.name)}</span><b>${a.pct}%</b></li>`).join('');
  }

  function allocationTable(el) {
    el.innerHTML = ALLOCATION.map((a, i) => `<tr><td><span class="swatch" style="background:${color(i)}"></span>${esc(a.name)}</td><td>${a.pct}%</td><td>${(SUPPLY * a.pct / 100).toLocaleString('en-US')}</td><td>${esc(a.release)}</td></tr>`).join('')
      + `<tr class="total"><td>Total</td><td>100%</td><td>${SUPPLY.toLocaleString('en-US')}</td><td>Fixed supply, created at genesis</td></tr>`;
  }

  function renderAllocation() {
    document.querySelectorAll('[data-chart="allocation"]').forEach((el) => stackedBar(el, ALLOCATION.map((a) => ({ value: a.pct, label: a.name, detail: `${a.pct}% · ${(SUPPLY * a.pct / 100).toLocaleString('en-US')} CYVBER` }))));
    document.querySelectorAll('[data-chart="allocation-legend"]').forEach(allocationLegend);
    document.querySelectorAll('[data-chart="allocation-table"]').forEach(allocationTable);
    document.querySelectorAll('[data-chart="unlock"]').forEach((el) => {
      const pts = Array.from({ length: FULL_UNLOCK_MONTH + 1 }, (_, m) => ({ x: m === 0 ? 'Launch' : `M${m}`, y: +unlockedTotal(m).toFixed(1), tip: `<b>${m === 0 ? 'At launch' : `Month ${m}`}</b><br>${unlockedTotal(m).toFixed(1)}% of supply unlocked (${millions(unlockedTotal(m))} million CYVBER)` }));
      lineChart(el, pts, { yLabel: 'Percent of supply unlocked', format: (v) => `${v}%`, max: 100 });
    });
    document.querySelectorAll('[data-chart="unlock-table"]').forEach((el) => {
      el.innerHTML = [0, 6, 12, 18, 24, 36, 48, FULL_UNLOCK_MONTH].map((m) => `<tr><td>${m === 0 ? 'At launch' : `Month ${m}`}</td><td>${unlockedTotal(m).toFixed(1)}%</td><td>${millions(unlockedTotal(m))} million</td></tr>`).join('');
    });
  }

  // ---- time series and bars (single series: no legend, the title names it) ----
  function axisFrame(el, w, h) {
    el.innerHTML = '';
    const svg = document.createElementNS(NS, 'svg');
    svg.setAttribute('viewBox', `0 0 ${w} ${h}`);
    svg.setAttribute('class', 'chart-svg');
    svg.setAttribute('role', 'img');
    el.appendChild(svg);
    return svg;
  }
  const node = (svg, tag, attrs) => { const n = document.createElementNS(NS, tag); for (const k in attrs) n.setAttribute(k, attrs[k]); svg.appendChild(n); return n; };
  // Four equal steps of a "nice" size (1, 2, 5 × 10^k; whole numbers when `integer`), topping out at or above v.
  const niceMax = (v, integer = false) => {
    if (v <= 0) return 4;
    const raw = v / 4, p = 10 ** Math.floor(Math.log10(raw)), m = raw / p;
    let step = (m <= 1 ? 1 : m <= 2 ? 2 : m <= 5 ? 5 : 10) * p;
    if (integer) step = Math.max(1, Math.ceil(step));
    return step * 4;
  };

  // points: [{x: label, y: number, tip: html}]
  function barChart(el, points, { yLabel = '', fill = 'var(--chart-1)', format = (v) => v, integer = false, max: fixedMax } = {}) {
    const W = el.clientWidth || 640, H = 220, L = 44, R = 10, T = 12, B = 26;
    const svg = axisFrame(el, W, H);
    svg.setAttribute('aria-label', yLabel);
    const max = fixedMax ?? niceMax(Math.max(...points.map((p) => p.y), 0), integer);
    const ph = H - T - B, pw = W - L - R;
    for (let i = 0; i <= 4; i++) {
      const y = T + ph - (ph * i) / 4;
      node(svg, 'line', { x1: L, x2: W - R, y1: y, y2: y, class: 'grid' });
      node(svg, 'text', { x: L - 8, y: y + 4, class: 'tick', 'text-anchor': 'end' }).textContent = format((max * i) / 4);
    }
    const slot = pw / Math.max(points.length, 1);
    const bw = Math.max(2, Math.min(28, slot - 2));
    points.forEach((p, i) => {
      const h = (p.y / max) * ph;
      const x = L + i * slot + (slot - bw) / 2;
      const r = Math.min(4, bw / 2, h);
      const d = h <= 0 ? '' : `M${x},${T + ph} V${T + ph - h + r} Q${x},${T + ph - h} ${x + r},${T + ph - h} H${x + bw - r} Q${x + bw},${T + ph - h} ${x + bw},${T + ph - h + r} V${T + ph} Z`;
      if (d) node(svg, 'path', { d, fill, class: 'bar' });
      const hit = node(svg, 'rect', { x: L + i * slot, y: T, width: slot, height: ph, fill: 'transparent', tabindex: 0 });
      const show = () => { const b = hit.getBoundingClientRect(); showTip(p.tip, b.left + b.width / 2, b.top + (ph - h) * (b.height / ph)); };
      hit.addEventListener('mouseenter', show); hit.addEventListener('focus', show);
      hit.addEventListener('mouseleave', hideTip); hit.addEventListener('blur', hideTip);
    });
    const step = Math.ceil(points.length / 6);
    points.forEach((p, i) => { if (i % step === 0) node(svg, 'text', { x: L + i * slot + slot / 2, y: H - 8, class: 'tick', 'text-anchor': 'middle' }).textContent = p.x; });
  }

  function lineChart(el, points, { yLabel = '', stroke = 'var(--chart-1)', format = (v) => v, max: fixedMax } = {}) {
    const W = el.clientWidth || 640, H = 220, L = 44, R = 12, T = 12, B = 26;
    const svg = axisFrame(el, W, H);
    svg.setAttribute('aria-label', yLabel);
    const max = fixedMax ?? niceMax(Math.max(...points.map((p) => p.y), 0));
    const ph = H - T - B, pw = W - L - R;
    for (let i = 0; i <= 4; i++) {
      const y = T + ph - (ph * i) / 4;
      node(svg, 'line', { x1: L, x2: W - R, y1: y, y2: y, class: 'grid' });
      node(svg, 'text', { x: L - 8, y: y + 4, class: 'tick', 'text-anchor': 'end' }).textContent = format((max * i) / 4);
    }
    const xs = (i) => L + (points.length < 2 ? pw / 2 : (pw * i) / (points.length - 1));
    const ys = (v) => T + ph - (v / max) * ph;
    if (points.length) node(svg, 'path', { d: points.map((p, i) => `${i ? 'L' : 'M'}${xs(i)},${ys(p.y)}`).join(' '), fill: 'none', stroke, 'stroke-width': 2, 'stroke-linejoin': 'round', 'stroke-linecap': 'round' });
    const cross = node(svg, 'line', { y1: T, y2: T + ph, class: 'cross', style: 'display:none' });
    const dot = node(svg, 'circle', { r: 4.5, fill: stroke, class: 'dot-ring', style: 'display:none' });
    const hit = node(svg, 'rect', { x: L, y: T, width: pw, height: ph, fill: 'transparent' });
    hit.addEventListener('mousemove', (e) => {
      const b = svg.getBoundingClientRect();
      const vx = ((e.clientX - b.left) / b.width) * W;
      const i = Math.max(0, Math.min(points.length - 1, Math.round(((vx - L) / pw) * (points.length - 1))));
      const p = points[i];
      cross.setAttribute('x1', xs(i)); cross.setAttribute('x2', xs(i)); cross.style.display = '';
      dot.setAttribute('cx', xs(i)); dot.setAttribute('cy', ys(p.y)); dot.style.display = '';
      showTip(p.tip, b.left + (xs(i) / W) * b.width, b.top + (ys(p.y) / H) * b.height);
    });
    hit.addEventListener('mouseleave', () => { cross.style.display = 'none'; dot.style.display = 'none'; hideTip(); });
    const step = Math.ceil(points.length / 6);
    points.forEach((p, i) => { if (i % step === 0) node(svg, 'text', { x: xs(i), y: H - 8, class: 'tick', 'text-anchor': 'middle' }).textContent = p.x; });
  }

  window.CYVBERCharts = { ALLOCATION, SUPPLY, unlockedTotal, FULL_UNLOCK_MONTH, color, stackedBar, barChart, lineChart, renderAllocation, hideTip };
  document.addEventListener('DOMContentLoaded', renderAllocation);
  // Re-color when the theme toggle changes data-theme.
  new MutationObserver(renderAllocation).observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });
})();
