// CYVBER website: shared header/footer, theme, live network data and small interactions.

// Where the chain lives. On cyvber.com the public endpoints are used; opened from a file or
// localhost, the site talks to a local devnet node (which also serves the explorer at "/").
const ON_CYVBER_COM = /(^|\.)cyvber\.io$/.test(location.hostname);
const NODE = ON_CYVBER_COM ? 'https://rpc.cyvber.com' : 'http://127.0.0.1:26601';
const EXPLORER = ON_CYVBER_COM ? 'https://explorer.cyvber.com' : NODE;
const DECIMALS = 18;

const PAGES = [
  ['index.html', 'Home'],
  ['blockchain.html', 'Blockchain'],
  ['rwa.html', 'RWA'],
  ['learn.html', 'How it works'],
  ['token.html', 'CYVBER Token'],
  ['validators.html', 'Validators'],
  ['developers.html', 'Developers'],
  ['roadmap.html', 'Roadmap'],
  ['whitepaper.html', 'Whitepaper'],
  ['faq.html', 'FAQ'],
  ['wallet.html', 'Wallet'],
];

// The CYVBER logo mark (assets/cyvber-mark-128.png, cut out of the master logo).
const LOGO = '<img src="assets/cyvber-mark-128.png" alt="" width="36" height="36">';
const ICON_SUN = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>';
const ICON_MOON = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/></svg>';
const ICON_MENU = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 7h16M4 12h16M4 17h16"/></svg>';

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const explorer = (route = '#/') => `${EXPLORER}/${route}`;

// ---------- theme ----------
function storedTheme() {
  try { return localStorage.getItem('cyvber-theme'); } catch { return null; }
}
function applyTheme(theme) {
  if (theme) document.documentElement.dataset.theme = theme;
  else delete document.documentElement.dataset.theme;
}
function currentTheme() {
  return document.documentElement.dataset.theme || 'dark'; // dark by default, like the explorer
}
applyTheme(storedTheme());

// ---------- header and footer ----------
function renderChrome() {
  const page = document.body.dataset.page || 'index.html';
  const header = $('#site-header');
  if (header) {
    header.outerHTML = `
      <a class="skip" href="#main">Skip to content</a>
      <div class="notice">CYVBER is on ${ON_CYVBER_COM ? 'its public testnet' : 'devnet'}. Test CYV has no cash value. <a href="roadmap.html">See the roadmap</a></div>
      <header class="site-header">
        <div class="wrap">
          <a class="brand" href="index.html">${LOGO}CYVBER</a>
          <nav class="nav" id="nav" aria-label="Main">
            ${PAGES.slice(1).map(([href, label]) => `<a href="${href}"${href === page ? ' aria-current="page"' : ''}>${label}</a>`).join('')}
          </nav>
          <div class="header-actions">
            <button class="icon-btn" id="themeBtn" type="button" aria-label="Switch light or dark theme"></button>
            <a class="btn small primary hide-sm" href="${explorer()}" target="_blank" rel="noopener">Open Explorer ↗</a>
            <button class="icon-btn menu-btn" id="menuBtn" type="button" aria-label="Open menu" aria-expanded="false" aria-controls="nav">${ICON_MENU}</button>
          </div>
        </div>
      </header>`;
  }
  const footer = $('#site-footer');
  if (footer) {
    footer.outerHTML = `
      <footer class="site-footer">
        <div class="wrap">
          <div class="fcols">
            <div>
              <a class="brand" href="index.html">${LOGO}CYVBER</a>
              <p class="muted" style="margin-top:14px">A Layer-1 blockchain where payments are final in one block, with a fixed supply of 500,000,000 CYV.</p>
              <p class="muted" style="font-size:13.5px">Founder: Ryan Paul Gallardo Pillas · Contact: <span class="todo-flag">to confirm</span></p>
            </div>
            <div><h4>Learn</h4><ul><li><a href="learn.html">How it works</a></li><li><a href="whitepaper.html">Whitepaper</a></li><li><a href="token.html">CYVBER token</a></li><li><a href="faq.html">FAQ</a></li><li><a href="faq.html#glossary">Glossary</a></li></ul></div>
            <div><h4>Use</h4><ul><li><a href="wallet.html">Wallet</a></li><li><a href="index.html#start">Get started</a></li><li><a href="${explorer()}" target="_blank" rel="noopener">Explorer ↗</a></li><li><a href="index.html#start">Faucet</a></li><li><a href="validators.html">Validators</a></li><li><a href="network.html">Network status</a></li></ul></div>
            <div><h4>Build</h4><ul><li><a href="developers.html">Developer guide</a></li><li><a href="developers.html#api">HTTP API</a></li><li><a href="developers.html#cli">Command-line wallet</a></li><li><a href="developers.html#node">Run a node</a></li></ul></div>
            <div><h4>Project</h4><ul><li><a href="roadmap.html">Roadmap</a></li><li><a href="roadmap.html#status">Status &amp; limits</a></li><li><a href="token.html#legal">Legal notice</a></li></ul></div>
          </div>
          <div class="legal">
            <span>Cognitum Tech Inc.</span>
            <span>cyvber.com · <span id="footStatus">devnet</span></span>
          </div>
        </div>
      </footer>`;
  }

  const themeBtn = $('#themeBtn');
  const paintThemeBtn = () => { themeBtn.innerHTML = currentTheme() === 'dark' ? ICON_SUN : ICON_MOON; themeBtn.title = currentTheme() === 'dark' ? 'Switch to light theme' : 'Switch to dark theme'; };
  if (themeBtn) {
    paintThemeBtn();
    themeBtn.addEventListener('click', () => {
      const next = currentTheme() === 'dark' ? 'light' : 'dark';
      applyTheme(next);
      try { localStorage.setItem('cyvber-theme', next); } catch {}
      paintThemeBtn();
    });
  }
  const menuBtn = $('#menuBtn');
  if (menuBtn) menuBtn.addEventListener('click', () => {
    const open = $('#nav').classList.toggle('open');
    menuBtn.setAttribute('aria-expanded', String(open));
  });
}

// ---------- copy buttons on code blocks ----------
function addCopyButtons() {
  for (const pre of $$('.code pre')) {
    const btn = document.createElement('button');
    btn.className = 'copy';
    btn.type = 'button';
    btn.textContent = 'Copy';
    btn.addEventListener('click', async () => {
      const text = pre.innerText.replace(/^\$ /gm, '');
      try { await navigator.clipboard.writeText(text); btn.textContent = 'Copied'; }
      catch { btn.textContent = 'Select & copy'; }
      setTimeout(() => (btn.textContent = 'Copy'), 1400);
    });
    // Wrap the <pre> so the button sits inside the code box, not on its label.
    const box = document.createElement('div');
    box.className = 'code-box';
    pre.replaceWith(box);
    box.append(pre, btn);
  }
}

// ---------- formatting ----------
function fmtUnits(units, maxFrac = 4) {
  const v = BigInt(units), base = 10n ** BigInt(DECIMALS);
  const frac = (v % base).toString().padStart(DECIMALS, '0').slice(0, maxFrac).replace(/0+$/, '');
  return `${(v / base).toLocaleString('en-US')}${frac ? '.' + frac : ''}`;
}
function ago(ts) {
  const s = Math.max(0, Math.round((Date.now() - ts) / 1000));
  if (s < 60) return `${s}s ago`;
  const m = Math.floor(s / 60);
  return m < 60 ? `${m}m ago` : `${Math.floor(m / 60)}h ago`;
}
const short = (s, a = 8, b = 4) => (s.length > a + b + 1 ? `${s.slice(0, a)}…${s.slice(-b)}` : s);

async function getJson(path, base = NODE) {
  const res = await fetch(base + path, { signal: AbortSignal.timeout(2500) });
  const body = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(body.error || `HTTP ${res.status}`);
  return body;
}

// ---------- live network data ----------
// Fills any element with data-live="<key>"; pages opt in by including such elements.
const names = new Map();
let lastHeight = 0;

async function refreshLive() {
  const scope = $$('[data-live-scope]');
  let status;
  try {
    status = await getJson('/status');
  } catch {
    scope.forEach((el) => el.classList.add('is-offline'));
    setLive('state', 'Network offline');
    $$('[data-live-dot]').forEach((d) => (d.className = 'dot off'));
    const fs = $('#footStatus'); if (fs) fs.textContent = 'devnet offline';
    return;
  }
  scope.forEach((el) => el.classList.remove('is-offline'));
  $$('[data-live-dot]').forEach((d) => (d.className = 'dot pulse'));
  const fs = $('#footStatus'); if (fs) fs.textContent = `${status.chainId} · block ${status.height.toLocaleString('en-US')}`;
  if (!names.size) status.validators.forEach((a, i) => names.set(a, `Validator ${i + 1}`));

  const netLabel = status.chainId.includes('testnet') ? 'Testnet' : 'Devnet';
  setLive('state', `${netLabel} live`);
  setLive('height', status.height.toLocaleString('en-US'));
  setLive('txCount', status.txCount.toLocaleString('en-US'));
  setLive('quorum', `${status.quorum} of ${status.validators.length}`);
  setLive('validatorsTotal', String(status.validators.length));
  setLive('chainId', status.chainId);

  const needsValidators = $$('[data-live="validatorsOnline"], [data-live="validatorList"]').length > 0;
  if (needsValidators) {
    const net = await getJson('/network').catch(() => ({ nodes: [] }));
    const online = new Set(net.nodes.map((n) => n.validator).filter(Boolean));
    setLive('validatorsOnline', `${online.size} of ${status.validators.length}`);
    setLive('validatorList', status.validators.map((a) => `<span title="${esc(a)}"><span class="dot ${online.has(a) ? '' : 'off'}"></span>${esc(names.get(a))}</span>`).join(''), true);
  }

  if (status.height !== lastHeight && $$('[data-live="blockFeed"], [data-live="blockTable"], [data-live="txTable"], [data-live="blockTime"], [data-live="lastBlockAge"]').length) {
    const [blocks, txs] = await Promise.all([getJson('/blocks?limit=6').catch(() => []), getJson('/txs?limit=6').catch(() => [])]);
    const prev = lastHeight;
    lastHeight = status.height;
    // Median gap between recent blocks, so a pause (e.g. a devnet that was switched off) doesn't skew it.
    if (blocks.length > 1) {
      const gaps = blocks.slice(1).map((b, i) => blocks[i].timestamp - b.timestamp).sort((x, y) => x - y);
      setLive('blockTime', `${(gaps[Math.floor(gaps.length / 2)] / 1000).toFixed(1)}s`);
    }
    $$('[data-live="lastBlockAge"]').forEach((el) => (el.dataset.ts = blocks[0]?.timestamp ?? ''));
    setLive('blockFeed', blocks.slice(0, 4).map((b) => `<li class="${prev && b.height > prev ? 'new' : ''}"><span class="bk">#${b.height}</span><span>${b.txCount} tx · ${b.signatures.length}/${status.validators.length} signed</span><span class="age" data-ts="${b.timestamp}"></span></li>`).join(''), true);
    setLive('blockTable', blocks.slice(0, 5).map((b) => `<tr><td><a href="${explorer('#/block/' + b.height)}" target="_blank" rel="noopener">#${b.height}</a></td><td>${esc(names.get(b.proposer) || short(b.proposer))}</td><td>${b.txCount}</td><td>${b.signatures.length}/${status.validators.length}</td><td class="muted" data-ts="${b.timestamp}"></td></tr>`).join('') || '<tr><td colspan="5" class="muted">No blocks yet</td></tr>', true);
    setLive('txTable', txs.slice(0, 5).map((t) => `<tr><td><a class="mono" href="${explorer('#/tx/' + t.hash)}" target="_blank" rel="noopener">${t.hash.slice(0, 10)}…</a></td><td class="mono">${esc(short(t.from))}</td><td class="mono">${esc(short(t.to))}</td><td>${fmtUnits(t.amount)} CYVBER</td><td class="muted" data-ts="${t.timestamp}"></td></tr>`).join('') || '<tr><td colspan="5" class="muted">No transactions yet</td></tr>', true);
  }
  tickAges();
}

function setLive(key, value, html = false) {
  for (const el of $$(`[data-live="${key}"]`)) {
    if (html) { if (el.innerHTML !== value) el.innerHTML = value; }
    else el.textContent = value;
  }
}
function tickAges() {
  for (const el of $$('[data-ts]')) if (el.dataset.ts) el.textContent = ago(Number(el.dataset.ts));
}

// ---------- faucet and search ----------
function wireForms() {
  const faucet = $('#faucetForm');
  if (faucet) faucet.addEventListener('submit', async (e) => {
    e.preventDefault();
    const input = $('input', faucet), msg = $('#faucetMsg'), btn = $('button', faucet);
    const address = input.value.trim().toLowerCase();
    msg.className = 'form-msg';
    if (!/^cy[0-9a-f]{64}$/.test(address)) {
      msg.className = 'form-msg err';
      msg.textContent = 'That does not look like a CYVBER address. It starts with "cy" followed by 64 letters and numbers.';
      return;
    }
    btn.disabled = true;
    msg.textContent = 'Requesting test CYV…';
    try {
      const res = await fetch(`${NODE}/faucet`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ address }) });
      const body = await res.json();
      if (!res.ok) throw new Error(body.error);
      msg.innerHTML = `Sent ${esc(body.amount)} test CYV. It arrives with the next block (about 2 seconds). <a href="${explorer('#/address/' + address)}" target="_blank" rel="noopener">View your address ↗</a>`;
    } catch (err) {
      msg.className = 'form-msg err';
      msg.textContent = err.message === 'Failed to fetch' ? 'The devnet is not reachable right now. Start it with "npm run devnet" and try again.' : err.message;
    } finally {
      btn.disabled = false;
    }
  });

  const search = $('#searchForm');
  if (search) search.addEventListener('submit', (e) => {
    e.preventDefault();
    const q = $('input', search).value.trim().toLowerCase();
    const msg = $('#searchMsg');
    let route = null;
    if (/^\d+$/.test(q)) route = `#/block/${Number(q)}`;
    else if (/^cy[0-9a-f]{64}$/.test(q)) route = `#/address/${q}`;
    else if (/^[0-9a-f]{64}$/.test(q)) route = `#/tx/${q}`;
    if (!route) {
      msg.className = 'form-msg err';
      msg.textContent = 'Enter a block number, an address starting with "cy", or a 64-character transaction ID.';
      return;
    }
    msg.className = 'form-msg';
    msg.textContent = '';
    window.open(explorer(route), '_blank', 'noopener');
  });

  // Token page: what a transfer costs.
  const calc = $('#feeCalc');
  if (calc) {
    const update = () => {
      const amount = Number($('input', calc).value || 0);
      const fee = 0.0001;
      $('#calcReceive').textContent = `${amount.toLocaleString('en-US', { maximumFractionDigits: 6 })} CYVBER`;
      $('#calcTotal').textContent = `${(amount + fee).toLocaleString('en-US', { maximumFractionDigits: 6 })} CYVBER`;
    };
    $('input', calc).addEventListener('input', update);
    update();
  }
}

// ---------- table of contents highlight ----------
function wireToc() {
  const links = $$('.toc a');
  if (!links.length) return;
  const byId = new Map(links.map((a) => [a.getAttribute('href').slice(1), a]));
  const observer = new IntersectionObserver((entries) => {
    for (const entry of entries) {
      if (entry.isIntersecting) {
        links.forEach((a) => a.classList.remove('active'));
        byId.get(entry.target.id)?.classList.add('active');
      }
    }
  }, { rootMargin: '-20% 0px -70% 0px' });
  byId.forEach((_, id) => { const el = document.getElementById(id); if (el) observer.observe(el); });
}

// ---------- start ----------
renderChrome();
// The AI assistant bubble (assets/assistant.js) on every page.
document.body.appendChild(Object.assign(document.createElement('script'), { src: 'assets/assistant.js?v=20261116a', defer: true }));
for (const a of $$('[data-explorer]')) { a.href = explorer(a.dataset.explorer); a.target = '_blank'; a.rel = 'noopener'; }
addCopyButtons();
wireForms();
wireToc();
refreshLive();
setInterval(refreshLive, 2000);
setInterval(tickAges, 1000);
