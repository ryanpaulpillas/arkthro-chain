// Real-world assets (ARS-1), live from the node: the asset list (GET /assets) and, where the page has
// room for it, each asset's details (GET /assets/:id). Uses site.js helpers.
(function () {
  const rows = document.getElementById('rwaAssets');
  const detail = document.getElementById('rwaDetail');
  if (!rows) return;
  const CLASS = { 'real-estate': 'Real estate', equity: 'Equity', debt: 'Debt', fund: 'Fund', commodity: 'Commodity', receivable: 'Receivable' };
  const KEYS = { pq: 'Post-quantum only', 'hash-based': 'Hash-based (SLH-DSA) only' };
  const ATTEST = { reserve: 'Proof of reserve', nav: 'Net asset value', appraisal: 'Appraisal', audit: 'Audit', distribution: 'Distribution' };
  const n = (s) => BigInt(s).toLocaleString('en-US');
  const short = (a) => (a ? `${a.slice(0, 8)}…${a.slice(-6)}` : 'none');

  function card(a) {
    const cap = a.rules.foreignCapBps;
    const share = a.foreignShareBps / 100;
    const gauge = cap === null ? '<p class="muted">No foreign-ownership cap.</p>' : `
      <div class="k" style="margin-top:14px">Foreign ownership: <b>${share}%</b> of a ${cap / 100}% cap</div>
      <div style="height:10px;border-radius:5px;background:var(--line,rgba(127,127,127,.25));margin-top:6px;position:relative;overflow:hidden">
        <div style="position:absolute;inset:0 auto 0 0;width:${Math.min(100, (share / (cap / 100)) * 100)}%;background:var(--grad,var(--emerald))"></div>
      </div>`;
    // Report links come from the chain (written by the attestor), so only plain https links are clickable.
    const att = a.lastAttestation ? `${esc(ATTEST[a.lastAttestation.kind] ?? a.lastAttestation.kind)} at block ${a.lastAttestation.height.toLocaleString('en-US')} ${/^https:\/\//.test(a.lastAttestation.uri) ? `(<a href="${esc(a.lastAttestation.uri)}" target="_blank" rel="noopener">report</a>)` : ''}` : 'none yet';
    return `<div class="card">
      <h3>${esc(a.symbol)} · ${esc(a.name)}</h3>
      <p class="muted">${esc(a.legal.entity)} · offering: ${esc(a.legal.offering)} · ${esc(a.legal.jurisdiction)}</p>
      <dl class="facts" style="margin-top:10px">
        <dt>Units</dt><dd>${n(a.supply)} of ${n(a.maxSupply)} issued, ${a.holders} holder${a.holders === 1 ? '' : 's'}</dd>
        <dt>Admin keys</dt><dd><span class="badge ok">${esc(KEYS[a.rules.adminKeys] ?? a.rules.adminKeys)}</span></dd>
        <dt>Issuer</dt><dd class="mono">${esc(short(a.roles.issuer))}</dd>
        <dt>Compliance</dt><dd class="mono">${esc(short(a.roles.compliance))}</dd>
        <dt>Recovery</dt><dd class="mono">${esc(short(a.roles.recovery))}</dd>
        <dt>Investors</dt><dd>${a.rules.kycRequired ? 'KYC required' : 'Open'}; ${esc(a.rules.investorClasses.join(', '))}</dd>
        <dt>Latest attestation</dt><dd>${att}</dd>
        <dt>Documents</dt><dd class="mono">${esc(short(a.legal.docsHash))}</dd>
      </dl>
      ${gauge}
      ${a.paused ? '<p><span class="badge out">Trading paused</span></p>' : ''}
    </div>`;
  }

  async function refresh() {
    let list;
    try {
      list = await getJson('/assets');
    } catch {
      rows.innerHTML = '<tr><td colspan="5" class="muted">The network is not reachable right now.</td></tr>';
      return;
    }
    rows.innerHTML = list.assets.length
      ? list.assets.map((a) => `<tr><td><b>${esc(a.symbol)}</b><div class="muted" style="font-size:13px">${esc(a.name)}</div></td><td>${esc(CLASS[a.class] ?? a.class)}</td><td>${n(a.supply)} of ${n(a.maxSupply)}</td><td>${a.holders}</td><td><span class="badge ok">${esc(KEYS[a.adminKeys] ?? a.adminKeys)}</span>${a.paused ? ' <span class="badge out">Paused</span>' : ''}</td></tr>`).join('')
      : '<tr><td colspan="5" class="muted">No assets on this network yet.</td></tr>';
    if (detail && list.assets.length) {
      const views = await Promise.all(list.assets.map((a) => getJson(`/assets/${a.assetId}`).catch(() => null)));
      detail.innerHTML = `<div class="grid g2">${views.filter(Boolean).map(card).join('')}</div>`;
    }
  }
  refresh();
  setInterval(refresh, 5000);
})();
