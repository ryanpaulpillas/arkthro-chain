// CYVBER website assistant: answers visitors' questions about CYVBER using the website's own pages
// as its knowledge, plus live network status, with Claude. Streams answers to the browser.
//
//   POST /api/assistant   { messages: [{ role: "user"|"assistant", content: string }, ...] }
//   -> text/event-stream: data: {"text": "..."} ... data: {"done": true}  (or {"error": "..."})
//
// Configuration (environment):
//   ANTHROPIC_API_KEY   required (or another credential the SDK understands)
//   ASSISTANT_PORT      default 8787
//   ASSISTANT_HOST      default 127.0.0.1 (put it behind the HTTPS proxy in production)
//   SITE_DIR            the website folder to learn from (default ../cyvber-site)
//   NODE_URL            a CYVBER node for live status (default http://127.0.0.1:26601)
//   ASSISTANT_MODEL     default claude-opus-5-5
//   ASSISTANT_EFFORT    default low (short website answers)
//   ALLOWED_ORIGINS     comma-separated origins allowed to call it from a browser
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import Anthropic from '@anthropic-ai/sdk';

const here = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.ASSISTANT_PORT ?? 8787);
const HOST = process.env.ASSISTANT_HOST ?? '127.0.0.1';
const SITE_DIR = path.resolve(here, process.env.SITE_DIR ?? '../cyvber-site');
const NODE_URL = (process.env.NODE_URL ?? 'http://127.0.0.1:26601').replace(/\/$/, '');
const MODEL = process.env.ASSISTANT_MODEL ?? 'claude-opus-5-5';
const EFFORT = process.env.ASSISTANT_EFFORT ?? 'low';
const ALLOWED_ORIGINS = new Set((process.env.ALLOWED_ORIGINS ?? 'https://cyvber.com,https://www.cyvber.com,http://localhost:8080,http://127.0.0.1:8080').split(',').map((s) => s.trim()).filter(Boolean));

// Pages the assistant learns from. foundations.html is deliberately hidden from the site, so it's excluded.
const PAGES = ['index.html', 'blockchain.html', 'learn.html', 'token.html', 'wallet.html', 'validators.html', 'network.html', 'developers.html', 'roadmap.html', 'whitepaper.html', 'faq.html'];
const LIMITS = { messages: 20, chars: 4000, perIpPerWindow: 20, windowMs: 10 * 60 * 1000, maxTokens: 4000 };

// ---------- knowledge from the website ----------
function pageText(html) {
  return html
    .replace(/<(script|style|svg|nav)[\s\S]*?<\/\1>/gi, ' ')
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<\/(p|h[1-6]|li|tr|dt|dd|div|section|summary|details|blockquote)>/gi, '\n')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&middot;|·/g, '·').replace(/&rarr;/g, '→')
    .replace(/[ \t]+/g, ' ')
    .replace(/\n\s*\n+/g, '\n')
    .trim();
}

function buildKnowledge() {
  const parts = [];
  for (const file of PAGES) {
    const full = path.join(SITE_DIR, file);
    if (!fs.existsSync(full)) continue;
    const html = fs.readFileSync(full, 'utf8');
    const title = html.match(/<title>([^<]*)<\/title>/i)?.[1] ?? file;
    parts.push(`<page file="${file}" title="${title}">\n${pageText(html)}\n</page>`);
  }
  if (!parts.length) throw new Error(`no website pages found in ${SITE_DIR} (set SITE_DIR)`);
  return parts.join('\n\n');
}

const SYSTEM_RULES = `You are the assistant on the CYVBER website (cyvber.com). Visitors ask you about the CYVBER blockchain: the CYVBER coin, the wallet, validators, the network, the roadmap, the technology and how to get started.

Your source of truth is the website content below; live network status arrives in a system message at the end of the conversation. Answer from those. When they don't cover something, say you don't know and point to the most relevant page rather than guessing - never invent figures, dates, prices, exchange listings, partners or team members. Items marked "to confirm" or "draft" (such as the tokenomics allocation) are not final; say so when you use them.

CYVBER is on devnet/testnet: test CYV has no cash value and there is no sale. Don't give investment advice or predict prices; if someone asks to buy CYVBER, explain that there is no sale and that anyone offering CYVBER for sale isn't authorized. Never ask for, accept or handle private keys or key files, and remind people never to share them. The founders' share is not published: it is part of the 15% Team allocation. If asked how much the founders hold, say only that founders are included in the Team allocation (15%, locked 1 year then unlocking monthly over 2 years) and that individual amounts are not disclosed.

Write short, plain answers in the visitor's language (for example English or Filipino). When a page helps, link it by file name, like [Wallet](wallet.html).`;

let knowledge = buildKnowledge();
let knowledgeBuiltAt = Date.now();
function system() {
  // Reload if the site changed (cheap check: refresh at most once a minute).
  if (Date.now() - knowledgeBuiltAt > 60_000) {
    try { knowledge = buildKnowledge(); } catch {}
    knowledgeBuiltAt = Date.now();
  }
  // One stable block, cached: the rules plus the whole site.
  return [{ type: 'text', text: `${SYSTEM_RULES}\n\n<website>\n${knowledge}\n</website>`, cache_control: { type: 'ephemeral' } }];
}

// ---------- live network status ----------
async function liveStatus() {
  try {
    const [status, net] = await Promise.all([
      fetch(`${NODE_URL}/status`, { signal: AbortSignal.timeout(2000) }).then((r) => r.json()),
      fetch(`${NODE_URL}/network`, { signal: AbortSignal.timeout(2000) }).then((r) => r.json()),
    ]);
    const online = net.nodes.filter((n) => n.validator).length;
    return `Live network status right now: network ${status.chainId}, latest block ${status.height}, ${online} of ${status.validators.length} validators online, ${status.quorum} signatures finalize a block, ${status.txCount} transactions since genesis, supply ${status.supply} (max ${status.maxSupply}).`;
  } catch {
    return 'Live network status is unavailable right now (the node did not answer).';
  }
}

// ---------- request handling ----------
const client = new Anthropic();
const hits = new Map(); // ip -> { count, resetAt }

function clientIp(req) {
  const remote = req.socket.remoteAddress ?? '';
  const local = remote === '127.0.0.1' || remote === '::1' || remote === '::ffff:127.0.0.1';
  return (local && String(req.headers['x-forwarded-for'] ?? '').split(',')[0].trim()) || remote;
}

function limited(ip) {
  const now = Date.now();
  const h = hits.get(ip);
  if (!h || h.resetAt <= now) { hits.set(ip, { count: 1, resetAt: now + LIMITS.windowMs }); return 0; }
  if (h.count >= LIMITS.perIpPerWindow) return h.resetAt - now;
  h.count++;
  return 0;
}
setInterval(() => { const now = Date.now(); for (const [ip, h] of hits) if (h.resetAt <= now) hits.delete(ip); }, 60_000).unref();

function validMessages(body) {
  const m = body?.messages;
  if (!Array.isArray(m) || !m.length || m.length > LIMITS.messages) return null;
  for (const [i, msg] of m.entries()) {
    if (!msg || typeof msg.content !== 'string' || !msg.content.trim() || msg.content.length > LIMITS.chars) return null;
    if (msg.role !== (i % 2 === 0 ? 'user' : 'assistant')) return null; // alternate, starting and ending with the visitor
  }
  if (m.at(-1).role !== 'user') return null;
  return m.map(({ role, content }) => ({ role, content: content.trim() }));
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', (c) => { size += c.length; if (size > 100_000) { reject(new Error('too large')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => { try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8') || 'null')); } catch { reject(new Error('bad json')); } });
    req.on('error', reject);
  });
}

function friendlyError(err) {
  if (err instanceof Anthropic.RateLimitError) return 'The assistant is busy right now. Please try again in a minute.';
  if (err instanceof Anthropic.AuthenticationError) return 'The assistant is not configured correctly (authentication).';
  if (err instanceof Anthropic.APIConnectionError) return 'The assistant could not reach its AI service. Please try again.';
  if (err instanceof Anthropic.APIError) return `The assistant hit an error (${err.status ?? 'unknown'}). Please try again.`;
  return 'Something went wrong. Please try again.';
}

async function handleAssistant(req, res) {
  const ip = clientIp(req);
  const wait = limited(ip);
  if (wait) return json(res, 429, { error: `Too many questions from your network. Try again in ${Math.ceil(wait / 60000)} minutes.` });
  let body;
  try { body = await readBody(req); } catch { return json(res, 400, { error: 'Request must be JSON.' }); }
  const messages = validMessages(body);
  if (!messages) return json(res, 400, { error: `Send up to ${LIMITS.messages} alternating messages of at most ${LIMITS.chars} characters, ending with the visitor's question.` });

  res.writeHead(200, { 'content-type': 'text/event-stream; charset=utf-8', 'cache-control': 'no-cache', connection: 'keep-alive', 'x-accel-buffering': 'no' });
  const send = (obj) => res.write(`data: ${JSON.stringify(obj)}\n\n`);
  let aborted = false;
  res.on('close', () => { aborted = true; });

  try {
    const stream = client.beta.messages.stream({
      model: MODEL,
      max_tokens: LIMITS.maxTokens, // cost cap for a website chat; answers are short
      betas: ['server-side-fallback-2026-07-01'],
      fallbacks: 'default', // if a safety classifier declines, retry on Anthropic's recommended fallback model
      output_config: { effort: EFFORT },
      system: system(),
      // Live status as a mid-conversation system message after the visitor's question: keeps the
      // cached system prompt and history prefix unchanged between requests.
      messages: [...messages, { role: 'system', content: await liveStatus() }],
    });
    for await (const event of stream) {
      if (aborted) { stream.abort(); return; }
      if (event.type === 'content_block_delta' && event.delta.type === 'text_delta') send({ text: event.delta.text });
    }
    const final = await stream.finalMessage();
    if (final.stop_reason === 'refusal') {
      send({ text: "\n\nI can't help with that one. I can answer questions about CYVBER, its wallet, network and roadmap." });
    } else if (final.stop_reason === 'max_tokens') {
      send({ text: '…' });
    }
    console.log(`[assistant] ${ip} ok in=${final.usage.input_tokens} cached=${final.usage.cache_read_input_tokens ?? 0} out=${final.usage.output_tokens} stop=${final.stop_reason}`);
    send({ done: true });
  } catch (err) {
    console.error('[assistant] error', err?.status ?? '', err?.message ?? err);
    send({ error: friendlyError(err) });
  } finally {
    res.end();
  }
}

function json(res, status, obj) {
  res.writeHead(status, { 'content-type': 'application/json' });
  res.end(JSON.stringify(obj));
}

const server = http.createServer(async (req, res) => {
  const origin = req.headers.origin;
  if (origin && ALLOWED_ORIGINS.has(origin)) {
    res.setHeader('access-control-allow-origin', origin);
    res.setHeader('vary', 'origin');
    res.setHeader('access-control-allow-headers', 'content-type');
    res.setHeader('access-control-allow-methods', 'POST, OPTIONS');
  }
  const url = new URL(req.url, 'http://local');
  if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }
  if (req.method === 'GET' && url.pathname === '/api/assistant/health') return json(res, 200, { ok: true, model: MODEL, pages: PAGES.filter((p) => fs.existsSync(path.join(SITE_DIR, p))).length });
  if (req.method === 'POST' && url.pathname === '/api/assistant') {
    if (origin && !ALLOWED_ORIGINS.has(origin)) return json(res, 403, { error: 'origin not allowed' });
    return handleAssistant(req, res);
  }
  json(res, 404, { error: 'not found' });
});

server.listen(PORT, HOST, () => console.log(`cyvber assistant on http://${HOST}:${PORT} · model ${MODEL} · ${knowledge.length.toLocaleString()} characters of site content from ${SITE_DIR}`));
